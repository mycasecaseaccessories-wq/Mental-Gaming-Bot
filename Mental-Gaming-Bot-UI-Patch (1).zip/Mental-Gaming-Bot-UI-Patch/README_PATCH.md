# Bot UI Patch

This patch intentionally changes only Telegram bot UI/routing files.

## Fixed
- Myanmar `💬 အကူအညီ` now always opens the Help Hub instead of being intercepted by the direct Support handler.
- Help Hub title, prompt, FAQ button, and Support button now use the existing EN/MM i18n system.
- Store Hub title, prompt, Shop, Premium Accounts, and Outline VPN button labels now use i18n.
- Outline VPN is hidden inside Store Hub when `SystemStatus.outlineBotUsername` is not configured, matching the main-menu shortcut behaviour.
- Store Hub gracefully continues without the VPN button if SystemStatus cannot be loaded.

## Not changed
Orders, wallet, payments, rewards, database models, admin flows, Mini App, and deployment configuration were not rewritten.
