Mental Gaming — Unified Channels Manager Patch

Changed files:
1) artifacts/bot/src/commands/channelManager.js
2) artifacts/bot/src/services/ChannelRegistryService.js
3) artifacts/bot/src/models/SystemStatus.js

Features added:
- Per-channel Manage button
- Edit bot-side display name / reset alias
- Add Role
- Remove Role with confirmation
- Remove Channel from all bot roles with confirmation
- Live Feed test from Manage panel
- Auto-post and Join Bonus reuse their existing setup wizards
- Auto-post / Join Bonus removal clearly warns that related configs will be deleted
- Unified channel aliases stored in SystemStatus.channelRegistryAliases

Install:
Copy these 3 files over the same paths in your repository, then deploy normally.

Typical VPS update after GitHub push:
cd /root/Mental-Gaming-Bot && git pull && pnpm install && pm2 restart mental-bot && pm2 logs mental-bot --lines 30

Validation performed:
- node -c passed for all 3 modified JS files.
- Existing npm test suite was attempted, but this extracted ZIP has no installed node_modules; mongoose was therefore unavailable in the local test environment. 10 dependency-light tests passed before the suite reported missing mongoose for the remaining tests.
