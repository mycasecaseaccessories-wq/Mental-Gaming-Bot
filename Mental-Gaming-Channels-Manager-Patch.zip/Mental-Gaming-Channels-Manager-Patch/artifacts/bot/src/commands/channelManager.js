/**
 * Unified Channel Manager (Admin) — /channels
 *
 * One place to inspect and manage every Telegram channel known by the bot.
 * Supports:
 *  - Add channel + assign purpose
 *  - Manage a channel from the combined registry
 *  - Edit the manager display name (does not rename the Telegram channel)
 *  - Add / remove roles
 *  - Remove the channel from all bot roles (with confirmation)
 *  - Live Feed test shortcut
 */

const { Markup } = require('telegraf');
const { adminOnly } = require('../middlewares/adminCheck');
const { config } = require('../../config/settings');
const {
  getKnownChannels,
  getKnownChannel,
  saveChannel,
  setChannelAlias,
  addRole,
  removeRole,
  removeAllRoles,
  SOURCE_LABELS,
  ALL_ROLES,
} = require('../services/ChannelRegistryService');

function escMd(s) {
  return String(s ?? '').replace(/([_*`\[\]])/g, '\\$1');
}

function roleButtonLabel(role) {
  return SOURCE_LABELS[role] || role;
}

function safeCb(prefix, value) {
  const data = `${prefix}:${value}`;
  return Buffer.byteLength(data, 'utf8') <= 64 ? data : null;
}

function resetCompetingWizards(ctx) {
  ctx.session.awaitingPromoCode = false;
  ctx.session.adminCreatePromo = null;
  ctx.session.adminGenCoupon = null;
  ctx.session.adminCouponAnnounce = null;
  ctx.session.cap = null;
  ctx.session.jbAdmin = null;
}

module.exports = (bot) => {
  async function showPanel(ctx) {
    const channels = await getKnownChannels();
    let body = `📡 *Channel Manager*\n\n`;

    if (!channels.length) {
      body += `Channel မရှိသေးပါဘူး — *➕ Channel ထည့်မယ်* ကို နှိပ်ပြီး ထည့်နိုင်ပါတယ်။`;
    } else {
      body += channels.map((c, i) => {
        const tags = c.sources.map((s) => SOURCE_LABELS[s] || s).join(', ');
        return `${i + 1}. *${escMd(c.title)}*\n   \`${escMd(c.chatId)}\`\n   ${tags}`;
      }).join('\n\n');
      body += `\n\n_Channel တစ်ခုချင်းကို Manage နှိပ်ပြီး နာမည်၊ role နဲ့ remove ကို တစ်နေရာတည်းက စီမံနိုင်ပါတယ်။_`;
    }

    const rows = [[Markup.button.callback('➕ Channel ထည့်မယ်', 'chmgr_add')]];
    for (const channel of channels) {
      const cb = safeCb('chmgr_manage', channel.chatId);
      if (cb) rows.push([Markup.button.callback(`⚙️ ${channel.title}`, cb)]);
    }
    rows.push([Markup.button.callback('🔄 Refresh', 'chmgr_refresh')]);

    await ctx.reply(body, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) });
  }

  async function showManage(ctx, chatId) {
    const channel = await getKnownChannel(chatId);
    if (!channel) return ctx.reply('❌ ဒီ channel က bot registry ထဲမှာ မရှိတော့ပါဘူး။');

    const roles = channel.sources.map((s) => SOURCE_LABELS[s] || s).join('\n• ');
    const body =
      `⚙️ *Channel Manage*\n\n` +
      `📌 Name: *${escMd(channel.title)}*\n` +
      `🆔 ID: \`${escMd(channel.chatId)}\`\n` +
      `🎯 Roles:\n• ${roles || '_မရှိ_'}\n\n` +
      `_✏️ Edit Name က Bot Channel Manager ထဲက display name ကိုပဲ ပြောင်းပါမယ်။ Telegram channel အမည်ကို မပြောင်းပါ။_`;

    const rows = [];
    if (channel.link && /^https:\/\/t\.me\//.test(channel.link)) {
      rows.push([Markup.button.url('🔗 Open Channel', channel.link)]);
    }
    const editCb = safeCb('chmgr_editname', channel.chatId);
    const addCb = safeCb('chmgr_addrole', channel.chatId);
    const remCb = safeCb('chmgr_remrole', channel.chatId);
    const delCb = safeCb('chmgr_removeall', channel.chatId);
    if (editCb) rows.push([Markup.button.callback('✏️ Edit Name', editCb)]);
    if (addCb) rows.push([Markup.button.callback('➕ Add Role', addCb), Markup.button.callback('➖ Remove Role', remCb)]);
    if (channel.sources.includes('livefeed')) {
      const testCb = safeCb('chmgr_testlivefeed', channel.chatId);
      if (testCb) rows.push([Markup.button.callback('🧪 Test Live Feed', testCb)]);
    }
    if (delCb) rows.push([Markup.button.callback('🗑 Remove Channel', delCb)]);
    rows.push([Markup.button.callback('⬅️ Channel List', 'chmgr_refresh')]);

    return ctx.reply(body, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) });
  }

  bot.command('channels', adminOnly(), (ctx) => showPanel(ctx));
  bot.hears('📡 Channels', adminOnly(), (ctx) => showPanel(ctx));

  bot.action('chmgr_refresh', adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    await showPanel(ctx);
  });

  bot.action(/^chmgr_manage:(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    await showManage(ctx, ctx.match[1]);
  });

  bot.action(/^chmgr_testlivefeed:(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery('Testing Live Feed…');
    const LiveFeedService = require('../services/LiveFeedService');
    const result = await LiveFeedService.sendTest(ctx.telegram, ctx.match[1]);
    await ctx.reply(`🧪 Live Feed test ပြီးပါပြီ။\n✅ Sent: ${result.sent}\n❌ Failed: ${result.failed}`);
  });

  // ── Edit display name ──────────────────────────────────────────────────────
  bot.action(/^chmgr_editname:(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const channel = await getKnownChannel(ctx.match[1]);
    if (!channel) return ctx.reply('❌ Channel မတွေ့တော့ပါ။');
    resetCompetingWizards(ctx);
    ctx.session.adminChannelMgr = { step: 'edit_name', chatId: channel.chatId };
    await ctx.reply(
      `✏️ *Display Name ပြောင်းမယ်*\n\nCurrent: *${escMd(channel.title)}*\n\n` +
      `နာမည်အသစ် ရိုက်ပါ။ Alias ကိုဖျက်ပြီး မူရင်းနာမည်ပြန်သုံးချင်ရင် \`reset\` ရိုက်ပါ။ မလုပ်တော့ရင် \`cancel\` ရိုက်ပါ။`,
      { parse_mode: 'Markdown', ...Markup.forceReply() }
    );
  });

  // ── Add role ───────────────────────────────────────────────────────────────
  bot.action(/^chmgr_addrole:(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const channel = await getKnownChannel(ctx.match[1]);
    if (!channel) return ctx.reply('❌ Channel မတွေ့တော့ပါ။');
    const available = ALL_ROLES.filter((r) => !channel.sources.includes(r));
    if (!available.length) return ctx.reply('✅ ဒီ channel မှာ ရနိုင်တဲ့ role အားလုံး ရှိပြီးသားပါ။');

    const rows = available.map((role) => {
      const cb = safeCb(`chmgr_setrole_${role}`, channel.chatId);
      return cb ? [Markup.button.callback(`➕ ${roleButtonLabel(role)}`, cb)] : null;
    }).filter(Boolean);
    rows.push([Markup.button.callback('⬅️ Back', `chmgr_manage:${channel.chatId}`)]);

    await ctx.reply(
      `➕ *Add Role*\n\n*${escMd(channel.title)}* ကို ဘာအတွက် ထပ်သုံးမလဲ?`,
      { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) }
    );
  });

  bot.action(/^chmgr_setrole_(saved|announce|backup|review|game|faq|livefeed):(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const role = ctx.match[1];
    const channel = await getKnownChannel(ctx.match[2]);
    if (!channel) return ctx.reply('❌ Channel မတွေ့တော့ပါ။');
    await addRole({ id: channel.chatId, title: channel.title, link: channel.link }, role, ctx.from.id);
    await ctx.reply(`✅ *${escMd(channel.title)}* ကို ${roleButtonLabel(role)} role ထည့်လိုက်ပါပြီ။`, { parse_mode: 'Markdown' });
    await showManage(ctx, channel.chatId);
  });

  // Auto-post and Join Bonus require their existing multi-step setup data.
  bot.action(/^chmgr_setrole_autopost:(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const channel = await getKnownChannel(ctx.match[1]);
    if (!channel) return ctx.reply('❌ Channel မတွေ့တော့ပါ။');
    resetCompetingWizards(ctx);
    ctx.session.adminChannelMgr = null;
    ctx.session.cap = { step: 'label', channelId: channel.chatId };
    return ctx.reply(
      `📅 *Auto-post Role Setup*\n\n✅ Channel: *${escMd(channel.title)}*\n\n` +
      `Step 2/5: Admin စာရင်းမှာ ပြမယ့် *နာမည်တို* ရိုက်ပါ (မထည့်ချင်ရင် \`skip\`):`,
      { parse_mode: 'Markdown', ...Markup.forceReply() }
    );
  });

  bot.action(/^chmgr_setrole_joinbonus:(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const channel = await getKnownChannel(ctx.match[1]);
    if (!channel) return ctx.reply('❌ Channel မတွေ့တော့ပါ။');
    resetCompetingWizards(ctx);
    ctx.session.adminChannelMgr = null;
    ctx.session.jbAdmin = {
      step: 'title', channelId: channel.chatId, chatTitle: channel.title, channelLink: channel.link || '',
    };
    return ctx.reply(
      `📣 *Join Bonus Role Setup*\n\n✅ Channel: *${escMd(channel.title)}*\n\n` +
      `Step 2/3: *ပြသမယ့် နာမည်* ရိုက်ပါ:`,
      { parse_mode: 'Markdown', ...Markup.forceReply() }
    );
  });

  // ── Remove role ────────────────────────────────────────────────────────────
  bot.action(/^chmgr_remrole:(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const channel = await getKnownChannel(ctx.match[1]);
    if (!channel) return ctx.reply('❌ Channel မတွေ့တော့ပါ။');

    const rows = channel.sources.map((role) => {
      const cb = safeCb(`chmgr_askrem_${role}`, channel.chatId);
      return cb ? [Markup.button.callback(`➖ ${roleButtonLabel(role)}`, cb)] : null;
    }).filter(Boolean);
    rows.push([Markup.button.callback('⬅️ Back', `chmgr_manage:${channel.chatId}`)]);

    await ctx.reply(
      `➖ *Remove Role*\n\n*${escMd(channel.title)}* ကနေ ဘယ် role ကို ဖယ်မလဲ?`,
      { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) }
    );
  });

  bot.action(/^chmgr_askrem_(saved|announce|backup|review|game|faq|livefeed|autopost|joinbonus):(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const role = ctx.match[1];
    const channel = await getKnownChannel(ctx.match[2]);
    if (!channel || !channel.sources.includes(role)) return ctx.reply('❌ ဒီ role မရှိတော့ပါ။');

    let warning = `ဒီ role ကိုပဲ ဖယ်ပါမယ်။ Channel ရဲ့ တခြား role တွေ မထိပါဘူး။`;
    if (role === 'autopost') warning = `⚠️ ဒီ channel အတွက် Auto-post schedule/config အားလုံးကို ဖျက်ပါမယ်။`;
    if (role === 'joinbonus') warning = `⚠️ ဒီ channel အတွက် Join Bonus offer/config အားလုံးကို ဖျက်ပါမယ်။ ယခင် claim history ကို မဖျက်ပါ။`;

    const yesCb = safeCb(`chmgr_dorem_${role}`, channel.chatId);
    await ctx.reply(
      `⚠️ *Confirm Remove Role*\n\nChannel: *${escMd(channel.title)}*\nRole: ${roleButtonLabel(role)}\n\n${warning}`,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('✅ ဖယ်မယ်', yesCb), Markup.button.callback('❌ မဖယ်တော့ပါ', `chmgr_manage:${channel.chatId}`)],
        ]),
      }
    );
  });

  bot.action(/^chmgr_dorem_(saved|announce|backup|review|game|faq|livefeed|autopost|joinbonus):(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const role = ctx.match[1];
    const chatId = ctx.match[2];
    const channel = await getKnownChannel(chatId);
    const title = channel?.title || chatId;
    const removed = await removeRole(chatId, role, ctx.from.id);
    if (!removed) return ctx.reply('❌ Role မရှိတော့ပါ (သို့) ဖယ်မရပါ။');
    await ctx.reply(`✅ *${escMd(title)}* ကနေ ${roleButtonLabel(role)} role ကို ဖယ်လိုက်ပါပြီ။`, { parse_mode: 'Markdown' });
    const stillThere = await getKnownChannel(chatId);
    if (stillThere) await showManage(ctx, chatId);
    else await showPanel(ctx);
  });

  // ── Remove entire channel from every bot role ──────────────────────────────
  bot.action(/^chmgr_removeall:(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const channel = await getKnownChannel(ctx.match[1]);
    if (!channel) return ctx.reply('❌ Channel မတွေ့တော့ပါ။');
    const cb = safeCb('chmgr_doremoveall', channel.chatId);
    await ctx.reply(
      `🗑 *Remove Channel*\n\n*${escMd(channel.title)}* ကို Bot ရဲ့ channel စာရင်းက အပြီးဖယ်မလား?\n\n` +
      `⚠️ Roles: ${channel.sources.map(roleButtonLabel).join(', ')}\n` +
      `Auto-post / Join Bonus config ပါရင် အဲဒီ config တွေလည်း ဖျက်ပါမယ်။ Telegram channel ကိုတော့ မဖျက်ပါ။`,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('🗑 အပြီးဖယ်မယ်', cb)],
          [Markup.button.callback('❌ မဖယ်တော့ပါ', `chmgr_manage:${channel.chatId}`)],
        ]),
      }
    );
  });

  bot.action(/^chmgr_doremoveall:(.+)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const chatId = ctx.match[1];
    const channel = await getKnownChannel(chatId);
    if (!channel) return ctx.reply('❌ Channel မတွေ့တော့ပါ။');
    const removed = await removeAllRoles(chatId, ctx.from.id);
    await ctx.reply(
      `✅ *${escMd(channel.title)}* ကို Bot channel registry က ဖယ်လိုက်ပါပြီ။\nRemoved: ${removed.map(roleButtonLabel).join(', ') || 'none'}`,
      { parse_mode: 'Markdown' }
    );
    await showPanel(ctx);
  });

  // ── Add new channel ────────────────────────────────────────────────────────
  bot.action('chmgr_add', adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    resetCompetingWizards(ctx);
    ctx.session.adminChannelMgr = { step: 'awaiting_channel' };
    await ctx.reply(
      `➕ *Channel ထည့်မယ်*\n\n` +
      `Channel ရဲ့ \`@username\` (သို့) channel ID (ဥပမာ \`-1001234567890\`) ကို ရိုက်ပါ:\n` +
      `_(Bot ကို အဲဒီ channel မှာ admin အရင်ထည့်ထားရပါမယ်။ မလုပ်တော့ရင် \`cancel\` ရိုက်ပါ)_`,
      { parse_mode: 'Markdown', ...Markup.forceReply() }
    );
  });

  bot.action(/^chmgr_purpose:(autopost|joinbonus|announce|backup|review|game|faq|livefeed|saved|cancel)$/, adminOnly(), async (ctx) => {
    await ctx.answerCbQuery();
    const purpose = ctx.match[1];
    const state = ctx.session?.adminChannelMgr;
    ctx.session.adminChannelMgr = null;
    if (purpose === 'cancel') return ctx.reply('👌 ပယ်ဖျက်လိုက်ပါပြီ။');

    const chat = state?.chat;
    if (!state || state.step !== 'purpose' || !chat) {
      return ctx.reply('❌ Session ကုန်သွားပါပြီ — ➕ Channel ထည့်မယ် ကို ပြန်နှိပ်ပြီး ထပ်စမ်းပါ။');
    }

    if (purpose === 'autopost') {
      ctx.session.cap = { step: 'label', channelId: chat.id };
      return ctx.reply(
        `📅 *Auto-post အတွက် သတ်မှတ်မယ်*\n\n✅ Channel: *${escMd(chat.title)}*\n\n` +
        `Step 2/5: Admin စာရင်းမှာ ပြမယ့် *နာမည်တို* ရိုက်ပါ (မထည့်ချင်ရင် \`skip\`):`,
        { parse_mode: 'Markdown', ...Markup.forceReply() }
      );
    }

    if (purpose === 'joinbonus') {
      ctx.session.jbAdmin = {
        step: 'title', channelId: chat.id, chatTitle: chat.title,
        channelLink: chat.username ? `https://t.me/${chat.username}` : (chat.invite_link || ''),
      };
      return ctx.reply(
        `📣 *Join Bonus အတွက် သတ်မှတ်မယ်*\n\n✅ Channel: *${escMd(chat.title)}*\n\n` +
        `Step 2/3: *ပြသမယ့် နာမည်* ရိုက်ပါ:`,
        { parse_mode: 'Markdown', ...Markup.forceReply() }
      );
    }

    if (purpose === 'saved') {
      await saveChannel({ id: chat.id, title: chat.title }, ctx.from.id);
    } else {
      await addRole(chat, purpose, ctx.from.id);
    }
    await ctx.reply(`✅ *${escMd(chat.title)}* ကို ${roleButtonLabel(purpose)} အဖြစ် သတ်မှတ်လိုက်ပါပြီ။`, { parse_mode: 'Markdown' });
    return showPanel(ctx);
  });

  // Text input shared by add-channel and edit-name flows.
  bot.on('text', async (ctx, next) => {
    const state = ctx.session?.adminChannelMgr;
    if (!state || ctx.from.id !== config.bot.adminId) return next();
    const input = ctx.message.text.trim();
    if (input.startsWith('/')) { ctx.session.adminChannelMgr = null; return next(); }
    if (/^cancel$/i.test(input)) {
      ctx.session.adminChannelMgr = null;
      return ctx.reply('👌 ပယ်ဖျက်လိုက်ပါပြီ။');
    }

    if (state.step === 'edit_name') {
      const chatId = state.chatId;
      ctx.session.adminChannelMgr = null;
      const title = /^reset$/i.test(input) ? '' : input;
      await setChannelAlias(chatId, title, ctx.from.id);
      await ctx.reply(title ? `✅ Display Name ကို *${escMd(title)}* လို့ ပြောင်းလိုက်ပါပြီ။` : '✅ Display Name alias ကို reset လုပ်လိုက်ပါပြီ။', { parse_mode: 'Markdown' });
      return showManage(ctx, chatId);
    }

    if (state.step !== 'awaiting_channel') return next();
    try {
      const chat = await ctx.telegram.getChat(input);
      if (chat.type !== 'channel') {
        return ctx.reply(`❌ ဒါက channel မဟုတ်ပါဘူး (${chat.type})။ Channel ရဲ့ @username (သို့) ID ကိုပဲ ရိုက်ပါ (သို့) \`cancel\` ရိုက်ပါ:`, { parse_mode: 'Markdown' });
      }
      ctx.session.adminChannelMgr = {
        step: 'purpose',
        chat: {
          id: String(chat.id), title: chat.title || input, username: chat.username || '', invite_link: chat.invite_link || '',
          link: chat.username ? `https://t.me/${chat.username}` : (chat.invite_link || ''),
        },
      };
      return ctx.reply(
        `✅ Channel တွေ့ပါပြီ: *${escMd(chat.title || input)}*\n\nဒီ channel ကို *ဘာအတွက်* သုံးမလဲ? 👇`,
        {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback('📅 Auto-post (နေ့စဉ် ကြော်ငြာတင်)', 'chmgr_purpose:autopost')],
            [Markup.button.callback('📣 Join Bonus (join ရင် MC ပေး)', 'chmgr_purpose:joinbonus')],
            [Markup.button.callback('📢 ကြေညာချက် channel', 'chmgr_purpose:announce')],
            [Markup.button.callback('🔐 Backup channel', 'chmgr_purpose:backup')],
            [Markup.button.callback('⭐ Review channel', 'chmgr_purpose:review')],
            [Markup.button.callback('🎮 Game Update channel', 'chmgr_purpose:game')],
            [Markup.button.callback('📖 FAQ channel', 'chmgr_purpose:faq')],
            [Markup.button.callback('📡 Live Feed', 'chmgr_purpose:livefeed')],
            [Markup.button.callback('💾 ရိုးရိုး စာရင်းထဲ သိမ်းမယ်', 'chmgr_purpose:saved')],
            [Markup.button.callback('❌ မလုပ်တော့ပါ', 'chmgr_purpose:cancel')],
          ]),
        }
      );
    } catch (e) {
      console.error('[ChannelManager] add channel error:', e.message);
      return ctx.reply(
        `❌ မထည့်လို့ရပါ — ${escMd(e.message)}\n\n` +
        `စစ်ရန်: ① channel ID/@username မှန်လား ② bot ကို channel မှာ admin ထည့်ထားလား\n` +
        `ထပ်ရိုက်ကြည့်ပါ (သို့) \`cancel\` ရိုက်ပါ:`,
        { parse_mode: 'Markdown' }
      );
    }
  });
};
