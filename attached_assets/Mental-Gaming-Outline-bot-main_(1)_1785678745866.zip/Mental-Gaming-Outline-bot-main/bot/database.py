import sqlite3
import os
import secrets

import crypto
from config import DB_PATH

_ENCRYPTED_SERVER_FIELDS = ("api_url", "cert_sha256", "ssh_password", "ssh_key")


def _decrypt_server(row):
    """Convert a server Row into a dict with sensitive fields decrypted."""
    if row is None:
        return None
    d = dict(row)
    for f in _ENCRYPTED_SERVER_FIELDS:
        if f in d:
            d[f] = crypto.decrypt(d[f])
    return d


def _decrypt_joined_row(row):
    """Decrypt any encrypted server fields present in a joined key/server row."""
    if row is None:
        return None
    d = dict(row)
    for f in _ENCRYPTED_SERVER_FIELDS:
        if f in d and d[f] is not None:
            d[f] = crypto.decrypt(d[f])
    return d


def get_conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    with get_conn() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS servers (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            name            TEXT    NOT NULL,
            api_url         TEXT    NOT NULL DEFAULT '',
            cert_sha256     TEXT    NOT NULL DEFAULT '',
            connection_type TEXT    NOT NULL DEFAULT 'api',
            ssh_host        TEXT,
            ssh_port        INTEGER DEFAULT 22,
            ssh_user        TEXT,
            ssh_password    TEXT,
            ssh_key         TEXT,
            created_at      TEXT    DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS keys (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            server_id       INTEGER NOT NULL,
            key_id          TEXT    NOT NULL,
            name            TEXT,
            data_limit_gb   REAL,
            expiry_date     TEXT,
            created_at      TEXT    DEFAULT (datetime('now')),
            is_disabled     INTEGER DEFAULT 0,
            auto_renew_days INTEGER DEFAULT 0,
            device_limit    INTEGER DEFAULT 0,
            share_token     TEXT,
            customer_tg_id  INTEGER,
            FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS admins (
            user_id    INTEGER PRIMARY KEY,
            username   TEXT,
            added_by   INTEGER,
            added_at   TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS payments (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            key_db_id   INTEGER,
            key_name    TEXT,
            amount      REAL    NOT NULL,
            currency    TEXT    DEFAULT 'MMK',
            note        TEXT,
            paid_at     TEXT    DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS customers (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            tg_user_id  INTEGER UNIQUE NOT NULL,
            name        TEXT,
            username    TEXT,
            joined_at   TEXT DEFAULT (datetime('now'))
        );
        """)
    _migrate()


def _migrate():
    """Add new columns to existing tables without breaking them."""
    new_server_cols = [
        ("connection_type", "TEXT NOT NULL DEFAULT 'api'"),
        ("ssh_host",        "TEXT"),
        ("ssh_port",        "INTEGER DEFAULT 22"),
        ("ssh_user",        "TEXT"),
        ("ssh_password",    "TEXT"),
        ("ssh_key",         "TEXT"),
    ]
    new_key_cols = [
        ("auto_renew_days", "INTEGER DEFAULT 0"),
        ("device_limit",    "INTEGER DEFAULT 0"),
        ("share_token",     "TEXT"),
        ("customer_tg_id",  "INTEGER"),
        ("note",            "TEXT"),
    ]
    conn = get_conn()
    try:
        existing_srv = {r[1] for r in conn.execute("PRAGMA table_info(servers)")}
        for col, definition in new_server_cols:
            if col not in existing_srv:
                try:
                    conn.execute(f"ALTER TABLE servers ADD COLUMN {col} {definition}")
                    conn.commit()
                except Exception:
                    pass

        existing_key = {r[1] for r in conn.execute("PRAGMA table_info(keys)")}
        for col, definition in new_key_cols:
            if col not in existing_key:
                try:
                    conn.execute(f"ALTER TABLE keys ADD COLUMN {col} {definition}")
                    conn.commit()
                except Exception:
                    pass

        _encrypt_existing_servers(conn)
    finally:
        conn.close()


def _encrypt_existing_servers(conn):
    """One-time: encrypt any legacy plaintext credential fields in the servers table."""
    try:
        rows = conn.execute("SELECT * FROM servers").fetchall()
    except Exception:
        return
    for row in rows:
        d = dict(row)
        updates = {}
        for f in _ENCRYPTED_SERVER_FIELDS:
            val = d.get(f)
            if val and not crypto.is_encrypted(val):
                updates[f] = crypto.encrypt(val)
        if updates:
            sets = ", ".join(f"{k} = ?" for k in updates)
            try:
                conn.execute(
                    f"UPDATE servers SET {sets} WHERE id = ?",
                    (*updates.values(), d["id"]),
                )
                conn.commit()
            except Exception:
                pass


# ── Servers ────────────────────────────────────────────────────────────────

def add_server(
    name: str,
    api_url: str,
    cert_sha256: str,
    connection_type: str = "api",
    ssh_host: str | None = None,
    ssh_port: int = 22,
    ssh_user: str | None = None,
    ssh_password: str | None = None,
    ssh_key: str | None = None,
) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO servers
               (name, api_url, cert_sha256, connection_type,
                ssh_host, ssh_port, ssh_user, ssh_password, ssh_key)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (name, crypto.encrypt(api_url), crypto.encrypt(cert_sha256), connection_type,
             ssh_host, ssh_port, ssh_user,
             crypto.encrypt(ssh_password), crypto.encrypt(ssh_key)),
        )
        return cur.lastrowid


def get_servers():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM servers ORDER BY id").fetchall()
        return [_decrypt_server(r) for r in rows]


def get_server(server_id: int):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM servers WHERE id = ?", (server_id,)
        ).fetchone()
        return _decrypt_server(row)


def delete_server(server_id: int):
    with get_conn() as conn:
        conn.execute("DELETE FROM servers WHERE id = ?", (server_id,))


# ── Keys ───────────────────────────────────────────────────────────────────

def add_key_record(
    server_id: int,
    key_id: str,
    name: str,
    data_limit_gb=None,
    expiry_date=None,
    auto_renew_days: int = 0,
    device_limit: int = 0,
    note: str | None = None,
) -> int:
    token = secrets.token_hex(16)
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO keys
               (server_id, key_id, name, data_limit_gb, expiry_date,
                auto_renew_days, device_limit, share_token, note)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (server_id, key_id, name, data_limit_gb, expiry_date,
             auto_renew_days, device_limit, token, note),
        )
        return cur.lastrowid


def set_key_note(server_id: int, key_id: str, note: str | None):
    with get_conn() as conn:
        conn.execute(
            "UPDATE keys SET note = ? WHERE server_id = ? AND key_id = ?",
            (note, server_id, key_id),
        )


def get_keys_by_server(server_id: int):
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM keys WHERE server_id = ? ORDER BY id", (server_id,)
        ).fetchall()


def get_all_keys():
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT k.*, s.name AS server_name, s.api_url, s.cert_sha256
               FROM keys k JOIN servers s ON k.server_id = s.id
               ORDER BY k.id"""
        ).fetchall()
        return [_decrypt_joined_row(r) for r in rows]


def get_key_record_by_vpn_id(server_id: int, key_id: str):
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM keys WHERE server_id = ? AND key_id = ?",
            (server_id, key_id),
        ).fetchone()


def get_key_by_share_token(token: str):
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM keys WHERE share_token = ?", (token,)
        ).fetchone()


def get_key_by_customer(tg_user_id: int):
    with get_conn() as conn:
        return conn.execute(
            """SELECT k.*, s.name AS server_name
               FROM keys k JOIN servers s ON k.server_id = s.id
               WHERE k.customer_tg_id = ?
               ORDER BY k.id""",
            (tg_user_id,),
        ).fetchall()


def delete_key_record_by_vpn_id(server_id: int, key_id: str):
    with get_conn() as conn:
        conn.execute(
            "DELETE FROM keys WHERE server_id = ? AND key_id = ?",
            (server_id, key_id),
        )


def set_key_disabled(server_id: int, key_id: str, disabled: bool):
    with get_conn() as conn:
        conn.execute(
            "UPDATE keys SET is_disabled = ? WHERE server_id = ? AND key_id = ?",
            (1 if disabled else 0, server_id, key_id),
        )


def set_key_expiry(server_id: int, key_id: str, expiry_date: str | None):
    with get_conn() as conn:
        conn.execute(
            "UPDATE keys SET expiry_date = ? WHERE server_id = ? AND key_id = ?",
            (expiry_date, server_id, key_id),
        )


def set_key_auto_renew(server_id: int, key_id: str, days: int):
    with get_conn() as conn:
        conn.execute(
            "UPDATE keys SET auto_renew_days = ? WHERE server_id = ? AND key_id = ?",
            (days, server_id, key_id),
        )


def assign_key_to_customer(server_id: int, key_id: str, tg_user_id: int | None):
    with get_conn() as conn:
        conn.execute(
            "UPDATE keys SET customer_tg_id = ? WHERE server_id = ? AND key_id = ?",
            (tg_user_id, server_id, key_id),
        )


def get_all_tracked_keys():
    """Keys with expiry or data limit — used by scheduler."""
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT k.*, s.api_url, s.cert_sha256, s.name AS server_name
               FROM keys k
               JOIN servers s ON k.server_id = s.id
               WHERE (k.expiry_date IS NOT NULL OR k.data_limit_gb IS NOT NULL)
               AND k.is_disabled = 0"""
        ).fetchall()
        return [_decrypt_joined_row(r) for r in rows]


# ── Admins ─────────────────────────────────────────────────────────────────

def get_admins():
    with get_conn() as conn:
        return conn.execute("SELECT * FROM admins ORDER BY added_at").fetchall()


def add_admin(user_id: int, username: str | None, added_by: int):
    with get_conn() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO admins (user_id, username, added_by) VALUES (?, ?, ?)",
            (user_id, username, added_by),
        )


def remove_admin(user_id: int):
    with get_conn() as conn:
        conn.execute("DELETE FROM admins WHERE user_id = ?", (user_id,))


def is_extra_admin(user_id: int) -> bool:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT 1 FROM admins WHERE user_id = ?", (user_id,)
        ).fetchone()
        return row is not None


# ── Payments ───────────────────────────────────────────────────────────────

def add_payment(
    key_db_id: int,
    key_name: str,
    amount: float,
    currency: str = "MMK",
    note: str = "",
) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO payments (key_db_id, key_name, amount, currency, note)
               VALUES (?, ?, ?, ?, ?)""",
            (key_db_id, key_name, amount, currency, note),
        )
        return cur.lastrowid


def get_payments_by_key(key_db_id: int):
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM payments WHERE key_db_id = ? ORDER BY paid_at DESC",
            (key_db_id,),
        ).fetchall()


def get_all_payments():
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM payments ORDER BY paid_at DESC LIMIT 50"
        ).fetchall()


# ── Customers ──────────────────────────────────────────────────────────────

def upsert_customer(tg_user_id: int, name: str | None, username: str | None):
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO customers (tg_user_id, name, username)
               VALUES (?, ?, ?)
               ON CONFLICT(tg_user_id) DO UPDATE
               SET name=excluded.name, username=excluded.username""",
            (tg_user_id, name, username),
        )


def get_customers():
    with get_conn() as conn:
        return conn.execute("SELECT * FROM customers ORDER BY joined_at DESC").fetchall()


def get_customer(tg_user_id: int):
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM customers WHERE tg_user_id = ?", (tg_user_id,)
        ).fetchone()


def remove_customer(tg_user_id: int):
    with get_conn() as conn:
        conn.execute("DELETE FROM customers WHERE tg_user_id = ?", (tg_user_id,))


def get_all_customer_ids() -> list[int]:
    with get_conn() as conn:
        rows = conn.execute("SELECT tg_user_id FROM customers").fetchall()
        return [r["tg_user_id"] for r in rows]
