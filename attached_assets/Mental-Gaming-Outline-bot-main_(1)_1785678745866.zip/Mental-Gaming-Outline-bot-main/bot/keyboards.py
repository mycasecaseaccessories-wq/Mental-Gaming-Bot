"""Inline keyboard builders — all labels come from messages module (bilingual)."""
import telebot.types as types
import messages as M


def main_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton(M.BTN_SERVER_MGMT, callback_data="menu:servers"),
        types.InlineKeyboardButton(M.BTN_KEY_MGMT,    callback_data="menu:keys"),
        types.InlineKeyboardButton(M.BTN_ADMINS,      callback_data="menu:admins"),
        types.InlineKeyboardButton(M.BTN_CUSTOMERS,   callback_data="menu:customers"),
        types.InlineKeyboardButton(M.BTN_BROADCAST,   callback_data="menu:broadcast"),
        types.InlineKeyboardButton(M.BTN_BACKUP,      callback_data="menu:backup"),
        types.InlineKeyboardButton(M.BTN_SET_BRAND,   callback_data="menu:brand"),
        types.InlineKeyboardButton(M.BTN_LANGUAGE,    callback_data="menu:lang"),
    )
    return kb


def server_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton(M.BTN_ADD_SERVER,    callback_data="srv:add"),
        types.InlineKeyboardButton(M.BTN_LIST_SERVERS,  callback_data="srv:list"),
        types.InlineKeyboardButton(M.BTN_DELETE_SERVER, callback_data="srv:del_select"),
        types.InlineKeyboardButton(M.BACK,              callback_data="menu:main"),
    )
    return kb


def lang_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton(M.BTN_LANG_MY, callback_data="lang:set:my"),
        types.InlineKeyboardButton(M.BTN_LANG_EN, callback_data="lang:set:en"),
    )
    kb.add(types.InlineKeyboardButton(M.BACK, callback_data="menu:main"))
    return kb


def add_server_type() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton(M.BTN_ADD_PROVISION, callback_data="srv:provision"),
        types.InlineKeyboardButton(M.BTN_ADD_VPS,       callback_data="srv:add_vps"),
        types.InlineKeyboardButton(M.BTN_ADD_API,       callback_data="srv:add_api"),
        types.InlineKeyboardButton(M.BACK,              callback_data="menu:servers"),
    )
    return kb


def vps_auth_type() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton(M.BTN_AUTH_PASSWORD, callback_data="vps:auth:password"),
        types.InlineKeyboardButton(M.BTN_AUTH_KEY,      callback_data="vps:auth:key"),
    )
    kb.add(types.InlineKeyboardButton(M.CANCEL, callback_data="menu:servers"))
    return kb


def server_list_keyboard(servers, action: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    for s in servers:
        kb.add(
            types.InlineKeyboardButton(
                f"🖥️ {s['name']}",
                callback_data=f"srv:{action}:{s['id']}",
            )
        )
    kb.add(types.InlineKeyboardButton(M.BACK, callback_data="menu:servers"))
    return kb


def confirm_delete_server(server_id: int) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton(M.BTN_YES_DELETE, callback_data=f"srv:del_confirm:{server_id}"),
        types.InlineKeyboardButton(M.BTN_NO_DELETE,  callback_data="srv:del_select"),
    )
    return kb


def key_menu(server_id: int) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton(M.BTN_CREATE_KEY,  callback_data=f"key:create:{server_id}"),
        types.InlineKeyboardButton(M.BTN_LIST_KEYS,   callback_data=f"key:list:{server_id}"),
        types.InlineKeyboardButton(M.BTN_VIEW_KEY,    callback_data=f"key:view_select:{server_id}"),
        types.InlineKeyboardButton(M.BTN_DELETE_KEY,  callback_data=f"key:del_select:{server_id}"),
        types.InlineKeyboardButton(M.BTN_KEY_USAGE,   callback_data=f"key:usage_select:{server_id}"),
        types.InlineKeyboardButton(M.BTN_TRAFFIC_ALL, callback_data=f"key:traffic_all:{server_id}"),
        types.InlineKeyboardButton(M.BTN_PAYMENTS,    callback_data=f"key:pay_select:{server_id}"),
        types.InlineKeyboardButton(M.BTN_SHARE_KEY,   callback_data=f"key:share_select:{server_id}"),
        types.InlineKeyboardButton(M.BTN_ASSIGN_CUST, callback_data=f"key:assign_select:{server_id}"),
        types.InlineKeyboardButton(M.BTN_SET_DOMAIN,  callback_data=f"key:domain:{server_id}"),
        types.InlineKeyboardButton(M.BTN_EDIT_NOTE,   callback_data=f"key:note_select:{server_id}"),
        types.InlineKeyboardButton(M.BACK,            callback_data="menu:keys"),
    )
    return kb


def data_limit_choice(server_id: int) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton(M.BTN_YES_LIMIT, callback_data=f"limit:yes:{server_id}"),
        types.InlineKeyboardButton(M.BTN_NO_LIMIT,  callback_data=f"limit:no:{server_id}"),
    )
    kb.add(types.InlineKeyboardButton(M.CANCEL, callback_data=f"key:menu:{server_id}"))
    return kb


def expiry_choice(server_id: int) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton(M.BTN_1M,        callback_data=f"expiry:30:{server_id}"),
        types.InlineKeyboardButton(M.BTN_3M,        callback_data=f"expiry:90:{server_id}"),
        types.InlineKeyboardButton(M.BTN_6M,        callback_data=f"expiry:180:{server_id}"),
        types.InlineKeyboardButton(M.BTN_1Y,        callback_data=f"expiry:365:{server_id}"),
        types.InlineKeyboardButton(M.BTN_NO_EXPIRY, callback_data=f"expiry:0:{server_id}"),
    )
    kb.add(types.InlineKeyboardButton(M.CANCEL, callback_data=f"key:menu:{server_id}"))
    return kb


def auto_renew_choice(server_id: int) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton(M.BTN_RENEW_30,  callback_data=f"renew:30:{server_id}"),
        types.InlineKeyboardButton(M.BTN_RENEW_90,  callback_data=f"renew:90:{server_id}"),
        types.InlineKeyboardButton(M.BTN_RENEW_365, callback_data=f"renew:365:{server_id}"),
        types.InlineKeyboardButton(M.BTN_NO_RENEW,  callback_data=f"renew:0:{server_id}"),
    )
    kb.add(types.InlineKeyboardButton(M.CANCEL, callback_data=f"key:menu:{server_id}"))
    return kb


def key_list_keyboard(keys, action: str, server_id: int) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    for k in keys:
        label = f"🔑 {k['name'] or k['key_id']}"
        if k["is_disabled"]:
            label = "🚫 " + label
        kb.add(
            types.InlineKeyboardButton(
                label,
                callback_data=f"key:{action}:{server_id}:{k['key_id']}",
            )
        )
    kb.add(types.InlineKeyboardButton(M.BACK, callback_data=f"key:menu:{server_id}"))
    return kb


def confirm_delete_key(server_id: int, key_id: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton(
            M.BTN_YES_DELETE,
            callback_data=f"key:del_confirm:{server_id}:{key_id}",
        ),
        types.InlineKeyboardButton(
            M.BTN_NO_DELETE,
            callback_data=f"key:del_select:{server_id}",
        ),
    )
    return kb


def back_to_key_menu(server_id: int) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton(M.BACK, callback_data=f"key:menu:{server_id}"))
    return kb


def back_to_main() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton(M.BACK, callback_data="menu:main"))
    return kb


# ── Admin Management ────────────────────────────────────────────────────────

def admin_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton(M.BTN_ADD_ADMIN,    callback_data="admin:add"),
        types.InlineKeyboardButton(M.BTN_LIST_ADMINS,  callback_data="admin:list"),
        types.InlineKeyboardButton(M.BTN_REMOVE_ADMIN, callback_data="admin:remove_select"),
        types.InlineKeyboardButton(M.BACK,             callback_data="menu:main"),
    )
    return kb


def admin_list_keyboard(admins) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    for a in admins:
        uname = a["username"] or str(a["user_id"])
        kb.add(
            types.InlineKeyboardButton(
                f"👤 {uname} ({a['user_id']})",
                callback_data=f"admin:remove:{a['user_id']}",
            )
        )
    kb.add(types.InlineKeyboardButton(M.BACK, callback_data="menu:admins"))
    return kb


# ── Customer Management ─────────────────────────────────────────────────────

def customer_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton(M.BTN_LIST_CUSTOMERS,  callback_data="cust:list"),
        types.InlineKeyboardButton(M.BTN_REMOVE_CUSTOMER, callback_data="cust:remove_select"),
        types.InlineKeyboardButton(M.BACK,                callback_data="menu:main"),
    )
    return kb


def customer_list_keyboard(customers) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    for c in customers:
        label = c["name"] or c["username"] or str(c["tg_user_id"])
        kb.add(
            types.InlineKeyboardButton(
                f"👤 {label}",
                callback_data=f"cust:remove:{c['tg_user_id']}",
            )
        )
    kb.add(types.InlineKeyboardButton(M.BACK, callback_data="menu:customers"))
    return kb


# ── Payment ─────────────────────────────────────────────────────────────────

def payment_menu(server_id: int, key_id: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton(
            M.BTN_ADD_PAYMENT,
            callback_data=f"pay:add:{server_id}:{key_id}",
        ),
        types.InlineKeyboardButton(
            M.BTN_VIEW_PAYMENTS,
            callback_data=f"pay:list:{server_id}:{key_id}",
        ),
        types.InlineKeyboardButton(M.BACK, callback_data=f"key:menu:{server_id}"),
    )
    return kb


# ── Broadcast ───────────────────────────────────────────────────────────────

def broadcast_confirm() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton(M.BTN_SEND_NOW, callback_data="broadcast:send"),
        types.InlineKeyboardButton(M.CANCEL,       callback_data="menu:main"),
    )
    return kb


# ── Customer self-service ───────────────────────────────────────────────────

def customer_self_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(types.InlineKeyboardButton(M.BTN_REFRESH, callback_data="cust:my_key"))
    return kb
