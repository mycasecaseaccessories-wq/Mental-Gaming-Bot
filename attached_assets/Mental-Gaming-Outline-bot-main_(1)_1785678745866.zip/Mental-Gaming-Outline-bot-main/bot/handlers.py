"""All bot command and callback handlers."""
import html
import logging
import threading
from datetime import datetime, timedelta

import telebot

import database as db
import keyboards as kb
import messages as M
import outline_client as oc
import settings_store as ss
import ssh_client as sc
from config import SHARE_BASE_URL

logger = logging.getLogger(__name__)

_pending: dict[int, dict] = {}


# ── Helpers ────────────────────────────────────────────────────────────────

def _get_admin_id() -> int:
    from config import ADMIN_USER_ID
    return ADMIN_USER_ID


def _is_primary_admin(uid: int) -> bool:
    return uid == _get_admin_id()


def _is_admin(uid: int) -> bool:
    return uid == _get_admin_id() or db.is_extra_admin(uid)


def _edit_or_send(bot: telebot.TeleBot, call, text: str, reply_markup=None):
    try:
        bot.edit_message_text(
            text,
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            parse_mode="HTML",
            reply_markup=reply_markup,
        )
    except Exception:
        bot.send_message(
            call.message.chat.id, text, parse_mode="HTML", reply_markup=reply_markup
        )


def _send(bot: telebot.TeleBot, chat_id: int, text: str, reply_markup=None):
    bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=reply_markup)


def _fmt_expiry(iso_date: str | None) -> str:
    if not iso_date:
        return M.NO_EXPIRY_TEXT
    try:
        return datetime.fromisoformat(iso_date).strftime("%Y-%m-%d")
    except Exception:
        return iso_date


def _fmt_limit(gb) -> str:
    return M.NO_LIMIT_TEXT if gb is None else f"{gb} GB"


def _fmt_renew(days) -> str:
    if not days:
        return M.NO_RENEW_TEXT
    return f"{days} ရက်" if M.get_lang() == "my" else f"{days} days"


def _fmt_devices(n) -> str:
    if not n:
        return M.NO_DEVICE_LIMIT
    return str(n)


def _share_url(token: str) -> str:
    if SHARE_BASE_URL:
        return f"{SHARE_BASE_URL}/share/{token}"
    return f"(SHARE_BASE_URL မသတ်မှတ်ရသေးပါ)"


def _server_display_host(server) -> str:
    if server["connection_type"] == "vps" and server["ssh_host"]:
        return server["ssh_host"]
    url = server["api_url"] or ""
    return url.split("/")[2] if "//" in url else url[:40]


def _step_guard(message: telebot.types.Message, bot: telebot.TeleBot, fallback_menu=None):
    uid = message.from_user.id
    if not _is_admin(uid):
        return None, None
    if not message.text:
        return uid, _pending.get(uid)
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        if fallback_menu:
            _send(bot, message.chat.id, M.CANCELLED, fallback_menu())
        else:
            _send(bot, message.chat.id, M.CANCELLED, kb.main_menu())
        return None, None
    p = _pending.get(uid)
    if p is None:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return None, None
    return uid, p


# ── /start ─────────────────────────────────────────────────────────────────

def handle_start(bot: telebot.TeleBot, message: telebot.types.Message):
    uid = message.from_user.id
    if _is_admin(uid):
        _pending.pop(uid, None)
        bot.send_message(
            message.chat.id, M.WELCOME, parse_mode="HTML", reply_markup=kb.main_menu()
        )
        return

    # Customer self-service
    name = message.from_user.full_name
    username = message.from_user.username
    db.upsert_customer(uid, name, username)
    keys = db.get_key_by_customer(uid)
    if not keys:
        _send(bot, message.chat.id, M.CUSTOMER_WELCOME)
        _send(bot, message.chat.id, M.CUSTOMER_NO_KEY, kb.customer_self_menu())
        return

    key_rec = keys[0]
    server = db.get_server(key_rec["server_id"])
    access_url = ""
    if server:
        try:
            vpn_keys = oc.list_keys(server["api_url"], server["cert_sha256"])
            for k in vpn_keys:
                if str(k.key_id) == str(key_rec["key_id"]):
                    access_url = k.access_url
                    break
        except Exception:
            pass

    _send(
        bot, message.chat.id,
        M.CUSTOMER_KEY_INFO.format(
            name=html.escape(str(key_rec["name"] or key_rec["key_id"])),
            limit=_fmt_limit(key_rec["data_limit_gb"]),
            expiry=_fmt_expiry(key_rec["expiry_date"]),
            status=M.STATUS_DISABLED if key_rec["is_disabled"] else M.STATUS_ACTIVE,
            access_url=html.escape(oc.apply_brand(access_url, ss.get_brand()) or "—"),
        ),
        kb.customer_self_menu(),
    )


# ── Callback router ────────────────────────────────────────────────────────

def handle_callback(bot: telebot.TeleBot, call: telebot.types.CallbackQuery):
    uid = call.from_user.id
    bot.answer_callback_query(call.id)
    data = call.data

    # Customer self-service callback
    if data == "cust:my_key":
        if _is_admin(uid):
            _edit_or_send(bot, call, M.MAIN_MENU_TEXT, kb.main_menu())
            return
        keys = db.get_key_by_customer(uid)
        if not keys:
            _edit_or_send(bot, call, M.CUSTOMER_NO_KEY, kb.customer_self_menu())
            return
        key_rec = keys[0]
        server = db.get_server(key_rec["server_id"])
        access_url = ""
        if server:
            try:
                vpn_keys = oc.list_keys(server["api_url"], server["cert_sha256"])
                for k in vpn_keys:
                    if str(k.key_id) == str(key_rec["key_id"]):
                        access_url = k.access_url
                        break
            except Exception:
                pass
        _edit_or_send(
            bot, call,
            M.CUSTOMER_KEY_INFO.format(
                name=html.escape(str(key_rec["name"] or key_rec["key_id"])),
                limit=_fmt_limit(key_rec["data_limit_gb"]),
                expiry=_fmt_expiry(key_rec["expiry_date"]),
                status=M.STATUS_DISABLED if key_rec["is_disabled"] else M.STATUS_ACTIVE,
                access_url=html.escape(oc.apply_brand(access_url, ss.get_brand()) or "—"),
            ),
            kb.customer_self_menu(),
        )
        return

    if not _is_admin(uid):
        return

    # ── Language ───────────────────────────────────────────────────────────
    if data == "menu:lang":
        _pending.pop(uid, None)
        _edit_or_send(bot, call, M.LANG_MENU_TEXT, kb.lang_menu())

    elif data.startswith("lang:set:"):
        lang = data.split(":")[2]
        ss.set_lang(lang)
        M.set_lang(lang)
        _edit_or_send(bot, call, M.LANG_SET, kb.main_menu())

    # ── Brand label ────────────────────────────────────────────────────────
    elif data == "menu:brand":
        _pending[uid] = {"flow": "set_brand"}
        current = ss.get_brand() or M.BRAND_NONE
        bot.send_message(
            call.message.chat.id,
            M.BRAND_MENU_TEXT.format(brand=current) + "\n\n" + M.ASK_BRAND,
            parse_mode="HTML",
        )
        msg = call.message
        bot.register_next_step_handler(msg, _step_set_brand, bot)

    # ── Main menus ─────────────────────────────────────────────────────────
    elif data == "menu:main":
        _pending.pop(uid, None)
        _edit_or_send(bot, call, M.MAIN_MENU_TEXT, kb.main_menu())

    elif data == "menu:servers":
        _pending.pop(uid, None)
        _edit_or_send(bot, call, M.SERVER_MENU_TEXT, kb.server_menu())

    elif data == "menu:keys":
        _pending.pop(uid, None)
        servers = db.get_servers()
        if not servers:
            _edit_or_send(bot, call, M.NO_SERVERS, kb.back_to_main())
            return
        _edit_or_send(bot, call, M.SELECT_SERVER_KEY, kb.server_list_keyboard(servers, "key_mgmt"))

    # ── Admin management ───────────────────────────────────────────────────
    elif data == "menu:admins":
        _pending.pop(uid, None)
        _edit_or_send(bot, call, M.ADMIN_MENU_TEXT, kb.admin_menu())

    elif data == "admin:add":
        if not _is_primary_admin(uid):
            _edit_or_send(bot, call, M.PRIMARY_ADMIN_ONLY, kb.admin_menu())
            return
        _pending[uid] = {"flow": "admin_add"}
        msg = bot.send_message(call.message.chat.id, M.ASK_ADMIN_ID, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_admin_add, bot)

    elif data == "admin:list":
        admins = db.get_admins()
        if not admins:
            _edit_or_send(bot, call, M.NO_EXTRA_ADMINS, kb.admin_menu())
            return
        text = M.ADMIN_LIST_HEADER.format(count=len(admins))
        for a in admins:
            text += M.ADMIN_ITEM.format(
                uid=a["user_id"],
                username=a["username"] or "—",
                date=a["added_at"][:10] if a["added_at"] else "—",
            )
        _edit_or_send(bot, call, text, kb.admin_menu())

    elif data == "admin:remove_select":
        if not _is_primary_admin(uid):
            _edit_or_send(bot, call, M.PRIMARY_ADMIN_ONLY, kb.admin_menu())
            return
        admins = db.get_admins()
        if not admins:
            _edit_or_send(bot, call, M.NO_EXTRA_ADMINS, kb.admin_menu())
            return
        _edit_or_send(bot, call, M.SELECT_ADMIN_REMOVE, kb.admin_list_keyboard(admins))

    elif data.startswith("admin:remove:"):
        if not _is_primary_admin(uid):
            _edit_or_send(bot, call, M.PRIMARY_ADMIN_ONLY, kb.admin_menu())
            return
        target_uid = int(data.split(":")[2])
        db.remove_admin(target_uid)
        _edit_or_send(bot, call, M.ADMIN_REMOVED.format(uid=target_uid), kb.admin_menu())

    # ── Customer management ────────────────────────────────────────────────
    elif data == "menu:customers":
        _pending.pop(uid, None)
        _edit_or_send(bot, call, M.CUSTOMER_MENU_TEXT, kb.customer_menu())

    elif data == "cust:list":
        customers = db.get_customers()
        if not customers:
            _edit_or_send(bot, call, M.NO_CUSTOMERS, kb.customer_menu())
            return
        text = M.CUSTOMER_LIST_HEADER.format(count=len(customers))
        for c in customers:
            text += M.CUSTOMER_ITEM.format(
                name=html.escape(c["name"] or "—"),
                username=html.escape(c["username"] or "—"),
                uid=c["tg_user_id"],
                date=c["joined_at"][:10] if c["joined_at"] else "—",
            )
        _edit_or_send(bot, call, text, kb.customer_menu())

    elif data == "cust:remove_select":
        customers = db.get_customers()
        if not customers:
            _edit_or_send(bot, call, M.NO_CUSTOMERS, kb.customer_menu())
            return
        _edit_or_send(bot, call, M.BTN_REMOVE_CUSTOMER, kb.customer_list_keyboard(customers))

    elif data.startswith("cust:remove:"):
        target_uid = int(data.split(":")[2])
        db.remove_customer(target_uid)
        _edit_or_send(bot, call, M.CANCELLED, kb.customer_menu())

    # ── Broadcast ──────────────────────────────────────────────────────────
    elif data == "menu:broadcast":
        _pending.pop(uid, None)
        cust_ids = db.get_all_customer_ids()
        if not cust_ids:
            _edit_or_send(bot, call, M.BROADCAST_NO_CUST, kb.back_to_main())
            return
        _pending[uid] = {"flow": "broadcast", "count": len(cust_ids)}
        msg = bot.send_message(call.message.chat.id, M.BROADCAST_TEXT, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_broadcast_text, bot)

    elif data == "broadcast:send":
        p = _pending.pop(uid, {})
        bcast_text = p.get("broadcast_text", "")
        if not bcast_text:
            _edit_or_send(bot, call, M.ERROR, kb.main_menu())
            return
        cust_ids = db.get_all_customer_ids()
        sent = 0

        def _do_broadcast():
            nonlocal sent
            for cid in cust_ids:
                try:
                    bot.send_message(cid, bcast_text, parse_mode="HTML")
                    sent += 1
                except Exception as e:
                    logger.warning(f"Broadcast to {cid} failed: {e}")
            try:
                bot.send_message(
                    call.message.chat.id,
                    M.BROADCAST_DONE.format(sent=sent),
                    parse_mode="HTML",
                    reply_markup=kb.main_menu(),
                )
            except Exception:
                pass

        threading.Thread(target=_do_broadcast, daemon=True).start()
        _edit_or_send(bot, call, f"⏳ Sending to {len(cust_ids)} customers…")

    # ── Backup ─────────────────────────────────────────────────────────────
    elif data == "menu:backup":
        if not _is_primary_admin(uid):
            _edit_or_send(bot, call, M.PRIMARY_ADMIN_ONLY, kb.main_menu())
            return
        _edit_or_send(bot, call, M.BACKUP_SENDING)
        from config import DB_PATH
        import os

        def _do_backup():
            try:
                with open(DB_PATH, "rb") as f:
                    now = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
                    bot.send_document(
                        uid,
                        f,
                        caption=f"💾 Database Backup — {now} UTC",
                        visible_file_name=f"bot_backup_{now}.db",
                    )
                bot.send_message(uid, M.BACKUP_DONE, parse_mode="HTML",
                                 reply_markup=kb.main_menu())
            except Exception as e:
                bot.send_message(uid, M.BACKUP_FAIL.format(error=str(e)),
                                 parse_mode="HTML", reply_markup=kb.main_menu())

        threading.Thread(target=_do_backup, daemon=True).start()

    # ── Server: add (type selector) ────────────────────────────────────────
    elif data == "srv:add":
        _pending.pop(uid, None)
        _edit_or_send(bot, call, M.ADD_SERVER_TYPE_TEXT, kb.add_server_type())

    # ── Auto-Provision flow ────────────────────────────────────────────────
    elif data == "srv:provision":
        _pending[uid] = {"flow": "provision", "step": "prov_name"}
        msg = bot.send_message(call.message.chat.id, M.ASK_SERVER_NAME, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_prov_name, bot)

    elif data == "srv:add_vps":
        _pending[uid] = {"flow": "vps", "step": "srv_name"}
        msg = bot.send_message(call.message.chat.id, M.ASK_SERVER_NAME, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_srv_name, bot)

    elif data == "srv:add_api":
        _pending[uid] = {"flow": "api", "step": "srv_name"}
        msg = bot.send_message(call.message.chat.id, M.ASK_SERVER_NAME, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_srv_name, bot)

    # ── Server: list ───────────────────────────────────────────────────────
    elif data == "srv:list":
        servers = db.get_servers()
        if not servers:
            _edit_or_send(bot, call, M.NO_SERVERS, kb.server_menu())
            return
        text = M.SERVER_LIST_HEADER.format(count=len(servers))
        for s in servers:
            ctype = M.CTYPE_VPS if s["connection_type"] == "vps" else M.CTYPE_API
            text += M.SERVER_ITEM.format(
                name=s["name"],
                ctype=ctype,
                host=_server_display_host(s),
            )
        _edit_or_send(bot, call, text, kb.server_menu())

    # ── Server: delete ─────────────────────────────────────────────────────
    elif data == "srv:del_select":
        servers = db.get_servers()
        if not servers:
            _edit_or_send(bot, call, M.NO_SERVERS, kb.server_menu())
            return
        _edit_or_send(bot, call, M.SELECT_SERVER_DELETE, kb.server_list_keyboard(servers, "del"))

    elif data.startswith("srv:del:"):
        server_id = int(data.split(":")[2])
        server = db.get_server(server_id)
        if not server:
            _edit_or_send(bot, call, M.ERROR, kb.server_menu())
            return
        _edit_or_send(
            bot, call,
            M.CONFIRM_DELETE_SERVER.format(name=server["name"]),
            kb.confirm_delete_server(server_id),
        )

    elif data.startswith("srv:del_confirm:"):
        server_id = int(data.split(":")[2])
        server = db.get_server(server_id)
        name = server["name"] if server else str(server_id)
        db.delete_server(server_id)
        _edit_or_send(bot, call, M.SERVER_DELETED.format(name=name), kb.server_menu())

    # ── VPS auth type (during SSH flow) ────────────────────────────────────
    elif data == "vps:auth:password":
        p = _pending.get(uid)
        if not p or p.get("step") != "vps_auth":
            _edit_or_send(bot, call, M.ERROR, kb.server_menu())
            return
        p["auth"] = "password"
        msg = bot.send_message(call.message.chat.id, M.ASK_VPS_PASSWORD, parse_mode="HTML")
        if p.get("flow") == "provision":
            bot.register_next_step_handler(msg, _step_prov_password, bot)
        else:
            bot.register_next_step_handler(msg, _step_vps_password, bot)

    elif data == "vps:auth:key":
        p = _pending.get(uid)
        if not p or p.get("step") != "vps_auth":
            _edit_or_send(bot, call, M.ERROR, kb.server_menu())
            return
        p["auth"] = "key"
        msg = bot.send_message(call.message.chat.id, M.ASK_VPS_KEY, parse_mode="HTML")
        if p.get("flow") == "provision":
            bot.register_next_step_handler(msg, _step_prov_key, bot)
        else:
            bot.register_next_step_handler(msg, _step_vps_key, bot)

    # ── Key management: server selector ────────────────────────────────────
    elif data.startswith("srv:key_mgmt:"):
        server_id = int(data.split(":")[2])
        server = db.get_server(server_id)
        if not server:
            _edit_or_send(bot, call, M.ERROR, kb.back_to_main())
            return
        _edit_or_send(
            bot, call,
            M.KEY_MENU_TEXT.format(server=server["name"]),
            kb.key_menu(server_id),
        )

    elif data.startswith("key:menu:"):
        server_id = int(data.split(":")[2])
        server = db.get_server(server_id)
        if not server:
            _edit_or_send(bot, call, M.ERROR, kb.back_to_main())
            return
        _pending.pop(uid, None)
        _edit_or_send(
            bot, call,
            M.KEY_MENU_TEXT.format(server=server["name"]),
            kb.key_menu(server_id),
        )

    # ── Key: create ────────────────────────────────────────────────────────
    elif data.startswith("key:create:"):
        server_id = int(data.split(":")[2])
        _pending[uid] = {"step": "key_name", "server_id": server_id}
        msg = bot.send_message(call.message.chat.id, M.ASK_KEY_NAME, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_key_name, bot)

    # ── Key: list ──────────────────────────────────────────────────────────
    elif data.startswith("key:list:"):
        server_id = int(data.split(":")[2])
        server = db.get_server(server_id)
        keys = db.get_keys_by_server(server_id)
        if not keys:
            _edit_or_send(bot, call, M.NO_RECORDS, kb.key_menu(server_id))
            return
        text = M.KEY_LIST_HEADER.format(server=server["name"], count=len(keys))
        for k in keys:
            text += M.KEY_ITEM.format(
                name=html.escape(str(k["name"] or k["key_id"])),
                key_id=k["key_id"],
                limit=_fmt_limit(k["data_limit_gb"]),
                expiry=_fmt_expiry(k["expiry_date"]),
                renew=_fmt_renew(k["auto_renew_days"]),
                devices=_fmt_devices(k["device_limit"]),
                status=M.STATUS_DISABLED if k["is_disabled"] else M.STATUS_ACTIVE,
            )
            note = k["note"] if "note" in k.keys() else None
            if note:
                text += M.NOTE_LINE.format(note=html.escape(note))
        _edit_or_send(bot, call, text, kb.key_menu(server_id))

    # ── Key: view existing access URL ──────────────────────────────────────
    elif data.startswith("key:view_select:"):
        server_id = int(data.split(":")[2])
        keys = db.get_keys_by_server(server_id)
        if not keys:
            _edit_or_send(bot, call, M.NO_RECORDS, kb.key_menu(server_id))
            return
        _edit_or_send(bot, call, M.SELECT_KEY_VIEW, kb.key_list_keyboard(keys, "view", server_id))

    elif data.startswith("key:view:"):
        parts = data.split(":", 3)
        server_id, key_id = int(parts[2]), parts[3]
        server = db.get_server(server_id)
        if not server:
            _edit_or_send(bot, call, M.ERROR, kb.key_menu(server_id))
            return
        key_rec = db.get_key_record_by_vpn_id(server_id, key_id)
        name = (key_rec["name"] if key_rec else None) or key_id
        ok, url, err = oc.get_key_access_url(server["api_url"], server["cert_sha256"], key_id)
        if ok:
            url = oc.apply_brand(url, ss.get_brand())
            _edit_or_send(
                bot, call,
                M.KEY_VIEW_TEXT.format(name=name, url=url),
                kb.back_to_key_menu(server_id),
            )
        else:
            _edit_or_send(
                bot, call,
                M.KEY_VIEW_FAIL.format(error=err),
                kb.back_to_key_menu(server_id),
            )

    # ── Key: delete ────────────────────────────────────────────────────────
    elif data.startswith("key:del_select:"):
        server_id = int(data.split(":")[2])
        keys = db.get_keys_by_server(server_id)
        if not keys:
            _edit_or_send(bot, call, M.NO_RECORDS, kb.key_menu(server_id))
            return
        _edit_or_send(bot, call, M.SELECT_KEY_DELETE, kb.key_list_keyboard(keys, "del", server_id))

    elif data.startswith("key:del:"):
        parts = data.split(":", 3)
        server_id, key_id = int(parts[2]), parts[3]
        key_rec = db.get_key_record_by_vpn_id(server_id, key_id)
        name = key_rec["name"] if key_rec else key_id
        _edit_or_send(
            bot, call,
            M.CONFIRM_DELETE_KEY.format(name=name),
            kb.confirm_delete_key(server_id, key_id),
        )

    elif data.startswith("key:del_confirm:"):
        parts = data.split(":", 3)
        server_id, key_id = int(parts[2]), parts[3]
        server = db.get_server(server_id)
        if not server:
            _edit_or_send(bot, call, M.ERROR, kb.back_to_main())
            return
        key_rec = db.get_key_record_by_vpn_id(server_id, key_id)
        name = key_rec["name"] if key_rec else key_id
        ok = oc.delete_key(server["api_url"], server["cert_sha256"], key_id)
        if ok:
            db.delete_key_record_by_vpn_id(server_id, key_id)
            _edit_or_send(bot, call, M.KEY_DELETED.format(name=name), kb.key_menu(server_id))
        else:
            _edit_or_send(bot, call, M.KEY_DELETE_FAIL, kb.key_menu(server_id))

    # ── Key: usage (single key) ────────────────────────────────────────────
    elif data.startswith("key:usage_select:"):
        server_id = int(data.split(":")[2])
        keys = db.get_keys_by_server(server_id)
        if not keys:
            _edit_or_send(bot, call, M.NO_RECORDS, kb.key_menu(server_id))
            return
        _edit_or_send(bot, call, M.SELECT_KEY_USAGE, kb.key_list_keyboard(keys, "usage", server_id))

    elif data.startswith("key:usage:"):
        parts = data.split(":", 3)
        server_id, key_id = int(parts[2]), parts[3]
        server = db.get_server(server_id)
        if not server:
            _edit_or_send(bot, call, M.ERROR, kb.back_to_main())
            return
        key_rec = db.get_key_record_by_vpn_id(server_id, key_id)
        ok_usage, usage, _ = oc.get_usage(server["api_url"], server["cert_sha256"])
        if not ok_usage:
            _edit_or_send(bot, call, M.USAGE_FETCH_FAIL, kb.back_to_key_menu(server_id))
            return
        used_bytes = usage.get(str(key_id), 0) or usage.get(key_id, 0)
        _edit_or_send(
            bot, call,
            M.KEY_USAGE_INFO.format(
                name=(key_rec["name"] if key_rec else key_id),
                key_id=key_id,
                used=oc.format_bytes(used_bytes),
                limit=_fmt_limit(key_rec["data_limit_gb"] if key_rec else None),
                expiry=_fmt_expiry(key_rec["expiry_date"] if key_rec else None),
                renew=_fmt_renew(key_rec["auto_renew_days"] if key_rec else 0),
                devices=_fmt_devices(key_rec["device_limit"] if key_rec else 0),
                status=M.STATUS_DISABLED if (key_rec and key_rec["is_disabled"]) else M.STATUS_ACTIVE,
            ),
            kb.back_to_key_menu(server_id),
        )

    # ── Key: traffic all (server-wide) ─────────────────────────────────────
    elif data.startswith("key:traffic_all:"):
        server_id = int(data.split(":")[2])
        server = db.get_server(server_id)
        if not server:
            _edit_or_send(bot, call, M.ERROR, kb.back_to_main())
            return
        ok_usage, usage, err = oc.get_usage(server["api_url"], server["cert_sha256"])
        if not ok_usage:
            _edit_or_send(bot, call, M.USAGE_FETCH_FAIL, kb.back_to_key_menu(server_id))
            return
        keys = db.get_keys_by_server(server_id)
        text = M.TRAFFIC_REPORT_HEADER.format(server=server["name"])
        total_bytes = 0
        for k in keys:
            used = usage.get(str(k["key_id"]), 0) or usage.get(k["key_id"], 0)
            total_bytes += used
            text += M.TRAFFIC_REPORT_ITEM.format(
                name=k["name"] or k["key_id"],
                used=oc.format_bytes(used),
                limit=_fmt_limit(k["data_limit_gb"]),
            )
        text += M.TRAFFIC_REPORT_TOTAL.format(total=oc.format_bytes(total_bytes))
        _edit_or_send(bot, call, text, kb.back_to_key_menu(server_id))

    # ── Key: share link ────────────────────────────────────────────────────
    elif data.startswith("key:share_select:"):
        server_id = int(data.split(":")[2])
        keys = db.get_keys_by_server(server_id)
        if not keys:
            _edit_or_send(bot, call, M.NO_RECORDS, kb.key_menu(server_id))
            return
        _edit_or_send(bot, call, M.BTN_SHARE_KEY, kb.key_list_keyboard(keys, "share", server_id))

    elif data.startswith("key:share:"):
        parts = data.split(":", 3)
        server_id, key_id = int(parts[2]), parts[3]
        key_rec = db.get_key_record_by_vpn_id(server_id, key_id)
        if not key_rec:
            _edit_or_send(bot, call, M.ERROR, kb.key_menu(server_id))
            return
        token = key_rec["share_token"]
        url = _share_url(token)
        _edit_or_send(
            bot, call,
            M.SHARE_LINK_TEXT.format(name=key_rec["name"] or key_id, url=url),
            kb.back_to_key_menu(server_id),
        )

    # ── Key: payment ───────────────────────────────────────────────────────
    elif data.startswith("key:pay_select:"):
        server_id = int(data.split(":")[2])
        keys = db.get_keys_by_server(server_id)
        if not keys:
            _edit_or_send(bot, call, M.NO_RECORDS, kb.key_menu(server_id))
            return
        _edit_or_send(bot, call, M.BTN_PAYMENTS, kb.key_list_keyboard(keys, "pay_menu", server_id))

    elif data.startswith("key:pay_menu:"):
        parts = data.split(":", 3)
        server_id, key_id = int(parts[2]), parts[3]
        key_rec = db.get_key_record_by_vpn_id(server_id, key_id)
        name = key_rec["name"] if key_rec else key_id
        _edit_or_send(
            bot, call,
            M.PAYMENT_MENU_TEXT.format(name=name),
            kb.payment_menu(server_id, key_id),
        )

    elif data.startswith("pay:add:"):
        parts = data.split(":", 3)
        server_id, key_id = int(parts[2]), parts[3]
        key_rec = db.get_key_record_by_vpn_id(server_id, key_id)
        _pending[uid] = {
            "flow": "payment_add",
            "server_id": server_id,
            "key_id": key_id,
            "key_db_id": key_rec["id"] if key_rec else None,
            "key_name": key_rec["name"] if key_rec else key_id,
        }
        msg = bot.send_message(call.message.chat.id, M.ASK_PAYMENT_AMOUNT, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_payment_amount, bot)

    elif data.startswith("pay:list:"):
        parts = data.split(":", 3)
        server_id, key_id = int(parts[2]), parts[3]
        key_rec = db.get_key_record_by_vpn_id(server_id, key_id)
        if not key_rec:
            _edit_or_send(bot, call, M.ERROR, kb.key_menu(server_id))
            return
        payments = db.get_payments_by_key(key_rec["id"])
        name = key_rec["name"] or key_id
        if not payments:
            _edit_or_send(bot, call, M.NO_PAYMENTS, kb.payment_menu(server_id, key_id))
            return
        text = M.PAYMENT_LIST_HEADER.format(name=name)
        total = 0.0
        for p in payments:
            text += M.PAYMENT_ITEM.format(
                amount=p["amount"],
                currency=p["currency"],
                date=p["paid_at"][:10] if p["paid_at"] else "—",
                note=p["note"] or "—",
            )
            if p["currency"] == "MMK":
                total += p["amount"]
        text += M.PAYMENT_TOTAL.format(total=int(total))
        _edit_or_send(bot, call, text, kb.payment_menu(server_id, key_id))

    # ── Key: assign customer ───────────────────────────────────────────────
    elif data.startswith("key:assign_select:"):
        server_id = int(data.split(":")[2])
        keys = db.get_keys_by_server(server_id)
        if not keys:
            _edit_or_send(bot, call, M.NO_RECORDS, kb.key_menu(server_id))
            return
        _edit_or_send(bot, call, M.SELECT_KEY_ASSIGN, kb.key_list_keyboard(keys, "assign", server_id))

    elif data.startswith("key:assign:"):
        parts = data.split(":", 3)
        server_id, key_id = int(parts[2]), parts[3]
        _pending[uid] = {
            "flow": "assign_customer",
            "server_id": server_id,
            "key_id": key_id,
        }
        msg = bot.send_message(call.message.chat.id, M.ASK_CUSTOMER_TG_ID, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_assign_customer, bot)

    # ── Key: set domain / hostname (server-wide) ───────────────────────────
    elif data.startswith("key:domain:"):
        server_id = int(data.split(":")[2])
        server = db.get_server(server_id)
        if not server:
            _edit_or_send(bot, call, M.ERROR, kb.key_menu(server_id))
            return
        _pending[uid] = {"flow": "set_domain", "server_id": server_id}
        msg = bot.send_message(call.message.chat.id, M.ASK_DOMAIN, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_set_domain, bot)

    # ── Key: note / comment (admin only) ───────────────────────────────────
    elif data.startswith("key:note_select:"):
        server_id = int(data.split(":")[2])
        keys = db.get_keys_by_server(server_id)
        if not keys:
            _edit_or_send(bot, call, M.NO_RECORDS, kb.key_menu(server_id))
            return
        _edit_or_send(bot, call, M.SELECT_KEY_NOTE, kb.key_list_keyboard(keys, "note", server_id))

    elif data.startswith("key:note:"):
        parts = data.split(":", 3)
        server_id, key_id = int(parts[2]), parts[3]
        _pending[uid] = {"flow": "set_note", "server_id": server_id, "key_id": key_id}
        msg = bot.send_message(call.message.chat.id, M.ASK_KEY_NOTE, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_set_note, bot)

    # ── Data limit / expiry / auto-renew choice (key creation) ────────────
    elif data.startswith("limit:yes:"):
        server_id = int(data.split(":")[2])
        p = _pending.get(uid, {})
        p["server_id"] = server_id
        p["step"] = "key_data_limit"
        _pending[uid] = p
        msg = bot.send_message(call.message.chat.id, M.ASK_DATA_LIMIT_VALUE, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_key_data_limit, bot)

    elif data.startswith("limit:no:"):
        server_id = int(data.split(":")[2])
        p = _pending.get(uid, {})
        p["server_id"] = server_id
        p["data_limit_gb"] = None
        p["step"] = "key_expiry"
        _pending[uid] = p
        bot.send_message(
            call.message.chat.id, M.ASK_EXPIRY,
            parse_mode="HTML", reply_markup=kb.expiry_choice(server_id),
        )

    elif data.startswith("expiry:"):
        parts = data.split(":")
        days, server_id = int(parts[1]), int(parts[2])
        p = _pending.get(uid, {})
        p["server_id"] = server_id
        p["expiry_date"] = (
            (datetime.utcnow() + timedelta(days=days)).isoformat() if days > 0 else None
        )
        _pending[uid] = p
        bot.send_message(
            call.message.chat.id, M.ASK_AUTO_RENEW,
            parse_mode="HTML", reply_markup=kb.auto_renew_choice(server_id),
        )

    elif data.startswith("renew:"):
        parts = data.split(":")
        renew_days, server_id = int(parts[1]), int(parts[2])
        p = _pending.get(uid, {})
        p["server_id"] = server_id
        p["auto_renew_days"] = renew_days
        _pending[uid] = p
        _finish_key_creation(bot, call, uid)


# ══════════════════════════════════════════════════════════════════════════
#  Step handlers — server name (shared by VPS and API flows)
# ══════════════════════════════════════════════════════════════════════════

def _step_srv_name(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_SERVER_NAME, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_srv_name, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.get(uid)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    p["name"] = message.text.strip()

    if p.get("flow") == "vps":
        p["step"] = "vps_ip"
        msg = bot.send_message(message.chat.id, M.ASK_VPS_IP, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_vps_ip, bot)
    else:
        p["step"] = "srv_url"
        msg = bot.send_message(message.chat.id, M.ASK_SERVER_URL, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_srv_url, bot)


# ══════════════════════════════════════════════════════════════════════════
#  VPS / SSH flow steps
# ══════════════════════════════════════════════════════════════════════════

def _step_vps_ip(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_VPS_IP, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_vps_ip, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.get(uid)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    p["vps_ip"] = message.text.strip()
    p["step"] = "vps_port"
    msg = bot.send_message(message.chat.id, M.ASK_VPS_PORT, parse_mode="HTML")
    bot.register_next_step_handler(msg, _step_vps_port, bot)


def _step_vps_port(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_VPS_PORT, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_vps_port, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.get(uid)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    try:
        port = int(message.text.strip())
        if not (1 <= port <= 65535):
            raise ValueError()
    except ValueError:
        msg = bot.send_message(message.chat.id, M.VPS_INVALID_PORT, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_vps_port, bot)
        return
    p["vps_port"] = port
    p["step"] = "vps_user"
    msg = bot.send_message(message.chat.id, M.ASK_VPS_USER, parse_mode="HTML")
    bot.register_next_step_handler(msg, _step_vps_user, bot)


def _step_vps_user(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_VPS_USER, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_vps_user, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.get(uid)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    p["vps_user"] = message.text.strip()
    p["step"] = "vps_auth"
    bot.send_message(
        message.chat.id, M.VPS_AUTH_TEXT,
        parse_mode="HTML", reply_markup=kb.vps_auth_type(),
    )


def _step_vps_password(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.get(uid)
    if not p or p.get("flow") != "vps":
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_VPS_PASSWORD, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_vps_password, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.pop(uid, None)
    p["vps_password"] = message.text
    _run_vps_discovery(bot, message.chat.id, uid, p)


def _step_vps_key(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.get(uid)
    if not p or p.get("flow") != "vps":
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_VPS_KEY, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_vps_key, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.pop(uid, None)
    p["vps_key"] = message.text.strip()
    _run_vps_discovery(bot, message.chat.id, uid, p)


def _run_vps_discovery(bot: telebot.TeleBot, chat_id: int, uid: int, p: dict):
    msg = bot.send_message(chat_id, M.VPS_CONNECTING, parse_mode="HTML")

    def _worker():
        host     = p.get("vps_ip", "")
        port     = p.get("vps_port", 22)
        username = p.get("vps_user", "root")
        password = p.get("vps_password")
        pkey_str = p.get("vps_key")
        name     = p.get("name", host)

        try:
            bot.edit_message_text(
                M.VPS_DISCOVERING, chat_id=chat_id, message_id=msg.message_id,
                parse_mode="HTML",
            )
            api_url, cert_sha256 = sc.discover_outline(
                host, port, username, password, pkey_str
            )
        except paramiko_error() as e:
            bot.edit_message_text(
                M.VPS_SSH_FAIL.format(error=str(e)),
                chat_id=chat_id, message_id=msg.message_id,
                parse_mode="HTML", reply_markup=kb.server_menu(),
            )
            return
        except RuntimeError as e:
            bot.edit_message_text(
                M.VPS_OUTLINE_FAIL.format(error=str(e)),
                chat_id=chat_id, message_id=msg.message_id,
                parse_mode="HTML", reply_markup=kb.server_menu(),
            )
            return
        except Exception as e:
            bot.edit_message_text(
                M.VPS_SSH_FAIL.format(error=str(e)),
                chat_id=chat_id, message_id=msg.message_id,
                parse_mode="HTML", reply_markup=kb.server_menu(),
            )
            return

        ok, err = oc.test_connection(api_url, cert_sha256)
        if not ok:
            bot.edit_message_text(
                M.SERVER_CONN_FAILED.format(error=err),
                chat_id=chat_id, message_id=msg.message_id,
                parse_mode="HTML", reply_markup=kb.server_menu(),
            )
            return

        db.add_server(
            name=name,
            api_url=api_url,
            cert_sha256=cert_sha256,
            connection_type="vps",
            ssh_host=host,
            ssh_port=port,
            ssh_user=username,
            ssh_password=None,
            ssh_key=None,
        )
        try:
            bot.edit_message_text(
                M.SERVER_ADDED.format(name=name),
                chat_id=chat_id, message_id=msg.message_id,
                parse_mode="HTML", reply_markup=kb.server_menu(),
            )
        except Exception:
            bot.send_message(
                chat_id, M.SERVER_ADDED.format(name=name),
                parse_mode="HTML", reply_markup=kb.server_menu(),
            )

    threading.Thread(target=_worker, daemon=True).start()


def paramiko_error():
    import paramiko
    return paramiko.SSHException


# ══════════════════════════════════════════════════════════════════════════
#  API URL flow steps
# ══════════════════════════════════════════════════════════════════════════

def _step_srv_url(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_SERVER_URL, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_srv_url, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.get(uid)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    p["api_url"] = message.text.strip()
    p["step"] = "srv_cert"
    msg = bot.send_message(message.chat.id, M.ASK_SERVER_CERT, parse_mode="HTML")
    bot.register_next_step_handler(msg, _step_srv_cert, bot)


def _step_srv_cert(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_SERVER_CERT, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_srv_cert, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.pop(uid, None)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    name    = p.get("name", "")
    api_url = p.get("api_url", "")
    cert    = message.text.strip()
    ok, err = oc.test_connection(api_url, cert)
    if not ok:
        _send(bot, message.chat.id, M.SERVER_CONN_FAILED.format(error=err), kb.server_menu())
        return
    db.add_server(name=name, api_url=api_url, cert_sha256=cert, connection_type="api")
    _send(bot, message.chat.id, M.SERVER_ADDED.format(name=name), kb.server_menu())


# ══════════════════════════════════════════════════════════════════════════
#  Key creation steps
# ══════════════════════════════════════════════════════════════════════════

def _step_key_name(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.get(uid)
    server_id = p.get("server_id") if p else None
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_KEY_NAME, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_key_name, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED,
              kb.key_menu(server_id) if server_id else kb.main_menu())
        return
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    p["key_name"] = message.text.strip()
    bot.send_message(
        message.chat.id, M.ASK_DATA_LIMIT,
        parse_mode="HTML", reply_markup=kb.data_limit_choice(server_id),
    )


def _step_key_data_limit(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.get(uid)
    server_id = p.get("server_id") if p else None
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_DATA_LIMIT_VALUE, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_key_data_limit, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED,
              kb.key_menu(server_id) if server_id else kb.main_menu())
        return
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    try:
        gb = float(message.text.strip().replace(",", "."))
        p["data_limit_gb"] = gb
    except ValueError:
        msg = bot.send_message(message.chat.id, M.INVALID_NUMBER, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_key_data_limit, bot)
        return
    bot.send_message(
        message.chat.id, M.ASK_EXPIRY,
        parse_mode="HTML", reply_markup=kb.expiry_choice(server_id),
    )


def _finish_key_creation(bot: telebot.TeleBot, call: telebot.types.CallbackQuery, uid: int):
    p = _pending.pop(uid, {})
    server_id      = p.get("server_id")
    server         = db.get_server(server_id)
    key_name       = p.get("key_name", "key")
    data_limit_gb  = p.get("data_limit_gb")
    expiry_date    = p.get("expiry_date")
    auto_renew_days = p.get("auto_renew_days", 0)

    if not server:
        _edit_or_send(bot, call, M.ERROR, kb.back_to_main())
        return
    try:
        limit_bytes = int(data_limit_gb * 1024 ** 3) if data_limit_gb else None
        vpn_key = oc.create_key(server["api_url"], server["cert_sha256"], key_name, limit_bytes)
        db.add_key_record(
            server_id=server_id,
            key_id=vpn_key.key_id,
            name=key_name,
            data_limit_gb=data_limit_gb,
            expiry_date=expiry_date,
            auto_renew_days=auto_renew_days,
        )
        key_rec = db.get_key_record_by_vpn_id(server_id, vpn_key.key_id)
        share_url = _share_url(key_rec["share_token"]) if key_rec else "—"
        _edit_or_send(
            bot, call,
            M.KEY_CREATED.format(
                name=key_name,
                limit=_fmt_limit(data_limit_gb),
                expiry=_fmt_expiry(expiry_date),
                renew=_fmt_renew(auto_renew_days),
                devices=_fmt_devices(0),
                access_url=oc.apply_brand(vpn_key.access_url, ss.get_brand()),
                share_url=share_url,
            ),
            kb.back_to_key_menu(server_id),
        )
    except Exception as e:
        logger.error(f"Key creation failed: {e}")
        _edit_or_send(bot, call, M.KEY_CREATE_FAIL.format(error=str(e)), kb.key_menu(server_id))


# ══════════════════════════════════════════════════════════════════════════
#  Admin management steps
# ══════════════════════════════════════════════════════════════════════════

def _step_admin_add(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_primary_admin(uid):
        return
    _pending.pop(uid, None)
    if not message.text or message.text.startswith("/"):
        _send(bot, message.chat.id, M.CANCELLED, kb.admin_menu())
        return
    try:
        target_uid = int(message.text.strip())
    except ValueError:
        _send(bot, message.chat.id, M.INVALID_NUMBER, kb.admin_menu())
        return
    if db.is_extra_admin(target_uid) or target_uid == _get_admin_id():
        _send(bot, message.chat.id, M.ADMIN_ALREADY, kb.admin_menu())
        return
    db.add_admin(target_uid, None, uid)
    _send(bot, message.chat.id, M.ADMIN_ADDED.format(uid=target_uid), kb.admin_menu())


# ══════════════════════════════════════════════════════════════════════════
#  Payment steps
# ══════════════════════════════════════════════════════════════════════════

def _step_payment_amount(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.get(uid)
    if not p or p.get("flow") != "payment_add":
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    if not message.text or message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.key_menu(p.get("server_id", 0)))
        return
    try:
        amount = float(message.text.strip().replace(",", ""))
    except ValueError:
        msg = bot.send_message(message.chat.id, M.INVALID_NUMBER, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_payment_amount, bot)
        return
    p["amount"] = amount
    msg = bot.send_message(message.chat.id, M.ASK_PAYMENT_NOTE, parse_mode="HTML")
    bot.register_next_step_handler(msg, _step_payment_note, bot)


def _step_payment_note(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.pop(uid, None)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    server_id = p.get("server_id", 0)
    key_id    = p.get("key_id", "")
    if not message.text or message.text.startswith("/"):
        _send(bot, message.chat.id, M.CANCELLED, kb.payment_menu(server_id, key_id))
        return
    note = "" if message.text.strip() == "-" else message.text.strip()
    db.add_payment(
        key_db_id=p.get("key_db_id"),
        key_name=p.get("key_name", ""),
        amount=p.get("amount", 0),
        note=note,
    )
    _send(
        bot, message.chat.id,
        M.PAYMENT_ADDED.format(amount=int(p.get("amount", 0))),
        kb.payment_menu(server_id, key_id),
    )


# ══════════════════════════════════════════════════════════════════════════
#  Assign customer step
# ══════════════════════════════════════════════════════════════════════════

def _step_set_domain(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.pop(uid, None)
    if not p or p.get("flow") != "set_domain":
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    server_id = p.get("server_id", 0)
    if not message.text or message.text.startswith("/"):
        _send(bot, message.chat.id, M.CANCELLED, kb.key_menu(server_id))
        return
    server = db.get_server(server_id)
    if not server:
        _send(bot, message.chat.id, M.ERROR, kb.key_menu(server_id))
        return
    host = message.text.strip()
    if not host:
        _send(bot, message.chat.id, M.CANCELLED, kb.key_menu(server_id))
        return
    ok, err = oc.set_hostname(server["api_url"], server["cert_sha256"], host)
    if ok:
        _send(bot, message.chat.id, M.DOMAIN_SET_OK.format(host=host), kb.key_menu(server_id))
    else:
        _send(bot, message.chat.id, M.DOMAIN_SET_FAIL.format(error=err), kb.key_menu(server_id))


def _step_set_brand(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.pop(uid, None)
    if not p or p.get("flow") != "set_brand":
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    if not message.text or message.text.startswith("/"):
        _send(bot, message.chat.id, M.CANCELLED, kb.main_menu())
        return
    text = message.text.strip()
    if text == "-":
        ss.set_brand("")
        _send(bot, message.chat.id, M.BRAND_CLEARED, kb.main_menu())
        return
    ss.set_brand(text)
    _send(bot, message.chat.id, M.BRAND_SET_OK.format(brand=text), kb.main_menu())


def _step_set_note(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.pop(uid, None)
    if not p or p.get("flow") != "set_note":
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    server_id = p.get("server_id", 0)
    key_id    = p.get("key_id", "")
    if not message.text or message.text.startswith("/"):
        _send(bot, message.chat.id, M.CANCELLED, kb.key_menu(server_id))
        return
    text = message.text.strip()
    if text == "-":
        db.set_key_note(server_id, key_id, None)
        _send(bot, message.chat.id, M.NOTE_CLEARED, kb.key_menu(server_id))
        return
    db.set_key_note(server_id, key_id, text)
    _send(bot, message.chat.id, M.NOTE_SET_OK, kb.key_menu(server_id))


def _step_assign_customer(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.pop(uid, None)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    server_id = p.get("server_id", 0)
    key_id    = p.get("key_id", "")
    if not message.text or message.text.startswith("/"):
        _send(bot, message.chat.id, M.CANCELLED, kb.key_menu(server_id))
        return
    try:
        cust_uid = int(message.text.strip())
    except ValueError:
        _send(bot, message.chat.id, M.INVALID_NUMBER, kb.key_menu(server_id))
        return
    key_rec = db.get_key_record_by_vpn_id(server_id, key_id)
    key_name = key_rec["name"] if key_rec else key_id
    if cust_uid == 0:
        db.assign_key_to_customer(server_id, key_id, None)
        _send(bot, message.chat.id, M.KEY_UNASSIGNED.format(key=key_name), kb.key_menu(server_id))
    else:
        db.assign_key_to_customer(server_id, key_id, cust_uid)
        _send(bot, message.chat.id, M.KEY_ASSIGNED.format(key=key_name, uid=cust_uid), kb.key_menu(server_id))


# ══════════════════════════════════════════════════════════════════════════
#  Broadcast step
# ══════════════════════════════════════════════════════════════════════════

def _step_broadcast_text(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.get(uid)
    if not p or p.get("flow") != "broadcast":
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    if not message.text or message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.main_menu())
        return
    bcast_text = html.escape(message.text.strip())
    count = p.get("count", 0)
    p["broadcast_text"] = bcast_text
    preview = bcast_text[:200] + ("…" if len(bcast_text) > 200 else "")
    bot.send_message(
        message.chat.id,
        M.BROADCAST_CONFIRM.format(count=count, preview=preview),
        parse_mode="HTML",
        reply_markup=kb.broadcast_confirm(),
    )


# ══════════════════════════════════════════════════════════════════════════
#  Auto-Provision step handlers
# ══════════════════════════════════════════════════════════════════════════

def _step_prov_name(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_SERVER_NAME, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_prov_name, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.get(uid)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    p["name"] = message.text.strip()
    p["step"] = "prov_ip"
    msg = bot.send_message(message.chat.id, M.ASK_PROVISION_IP, parse_mode="HTML")
    bot.register_next_step_handler(msg, _step_prov_ip, bot)


def _step_prov_ip(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_PROVISION_IP, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_prov_ip, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.get(uid)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    p["vps_ip"] = message.text.strip()
    p["step"] = "prov_port"
    msg = bot.send_message(message.chat.id, M.ASK_PROVISION_PORT, parse_mode="HTML")
    bot.register_next_step_handler(msg, _step_prov_port, bot)


def _step_prov_port(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_PROVISION_PORT, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_prov_port, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.get(uid)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    try:
        port = int(message.text.strip())
        if not (1 <= port <= 65535):
            raise ValueError()
    except ValueError:
        msg = bot.send_message(message.chat.id, M.VPS_INVALID_PORT, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_prov_port, bot)
        return
    p["vps_port"] = port
    p["step"] = "prov_user"
    msg = bot.send_message(message.chat.id, M.ASK_PROVISION_USER, parse_mode="HTML")
    bot.register_next_step_handler(msg, _step_prov_user, bot)


def _step_prov_user(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_PROVISION_USER, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_prov_user, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.get(uid)
    if not p:
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    p["vps_user"] = message.text.strip()
    p["step"] = "vps_auth"
    bot.send_message(
        message.chat.id, M.VPS_AUTH_TEXT,
        parse_mode="HTML", reply_markup=kb.vps_auth_type(),
    )


def _step_prov_password(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.get(uid)
    if not p or p.get("flow") != "provision":
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_VPS_PASSWORD, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_prov_password, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.pop(uid, None)
    p["vps_password"] = message.text
    _run_provision(bot, message.chat.id, uid, p)


def _step_prov_key(message: telebot.types.Message, bot: telebot.TeleBot):
    uid = message.from_user.id
    if not _is_admin(uid):
        return
    p = _pending.get(uid)
    if not p or p.get("flow") != "provision":
        _send(bot, message.chat.id, M.MAIN_MENU_TEXT, kb.main_menu())
        return
    if not message.text:
        msg = bot.send_message(message.chat.id, M.ASK_VPS_KEY, parse_mode="HTML")
        bot.register_next_step_handler(msg, _step_prov_key, bot)
        return
    if message.text.startswith("/"):
        _pending.pop(uid, None)
        _send(bot, message.chat.id, M.CANCELLED, kb.server_menu())
        return
    p = _pending.pop(uid, None)
    p["vps_key"] = message.text.strip()
    _run_provision(bot, message.chat.id, uid, p)


def _run_provision(bot: telebot.TeleBot, chat_id: int, uid: int, p: dict):
    """SSH into a fresh VPS, run the Outline installer, save credentials."""
    msg = bot.send_message(chat_id, M.PROVISION_CONNECTING, parse_mode="HTML")

    def _worker():
        host     = p.get("vps_ip", "")
        port     = p.get("vps_port", 22)
        username = p.get("vps_user", "root")
        password = p.get("vps_password")
        pkey_str = p.get("vps_key")
        name     = p.get("name", host)

        # Test SSH connectivity first
        ok_ssh, ssh_err = sc.test_ssh(host, port, username, password, pkey_str)
        if not ok_ssh:
            try:
                bot.edit_message_text(
                    M.VPS_SSH_FAIL.format(error=ssh_err),
                    chat_id=chat_id, message_id=msg.message_id,
                    parse_mode="HTML", reply_markup=kb.server_menu(),
                )
            except Exception:
                pass
            return

        # Show installing message
        try:
            bot.edit_message_text(
                M.PROVISION_INSTALLING,
                chat_id=chat_id, message_id=msg.message_id,
                parse_mode="HTML",
            )
        except Exception:
            pass

        def _progress(status_text: str):
            try:
                bot.edit_message_text(
                    M.PROVISION_PROGRESS.format(status=status_text),
                    chat_id=chat_id, message_id=msg.message_id,
                    parse_mode="HTML",
                )
            except Exception:
                pass

        try:
            api_url, cert_sha256, _ = sc.provision_outline(
                host, port, username, password, pkey_str,
                progress_callback=_progress,
                timeout=600,
            )
        except RuntimeError as e:
            try:
                bot.edit_message_text(
                    M.PROVISION_FAIL.format(error=str(e)),
                    chat_id=chat_id, message_id=msg.message_id,
                    parse_mode="HTML", reply_markup=kb.server_menu(),
                )
            except Exception:
                bot.send_message(
                    chat_id, M.PROVISION_FAIL.format(error=str(e)),
                    parse_mode="HTML", reply_markup=kb.server_menu(),
                )
            return
        except Exception as e:
            try:
                bot.edit_message_text(
                    M.PROVISION_FAIL.format(error=str(e)),
                    chat_id=chat_id, message_id=msg.message_id,
                    parse_mode="HTML", reply_markup=kb.server_menu(),
                )
            except Exception:
                bot.send_message(
                    chat_id, M.PROVISION_FAIL.format(error=str(e)),
                    parse_mode="HTML", reply_markup=kb.server_menu(),
                )
            return

        # Save to database
        db.add_server(
            name=name,
            api_url=api_url,
            cert_sha256=cert_sha256,
            connection_type="vps",
            ssh_host=host,
            ssh_port=port,
            ssh_user=username,
            ssh_password=None,
            ssh_key=None,
        )

        success_text = M.PROVISION_SUCCESS.format(name=name, host=host)
        try:
            bot.edit_message_text(
                success_text,
                chat_id=chat_id, message_id=msg.message_id,
                parse_mode="HTML", reply_markup=kb.server_menu(),
            )
        except Exception:
            bot.send_message(
                chat_id, success_text,
                parse_mode="HTML", reply_markup=kb.server_menu(),
            )

    threading.Thread(target=_worker, daemon=True).start()


# ── Register all handlers ──────────────────────────────────────────────────

def register(bot: telebot.TeleBot):
    bot.message_handler(commands=["start"])(
        lambda msg: handle_start(bot, msg)
    )
    bot.callback_query_handler(func=lambda c: True)(
        lambda call: handle_callback(bot, call)
    )
