"""SSH into a VPS: discover existing Outline or auto-install a fresh one."""
import io
import json
import logging
import re
import time

import paramiko

logger = logging.getLogger(__name__)

_ACCESS_PATHS = [
    "/opt/outline/access.txt",
    "/opt/shadowbox/access.txt",
    "/root/outline/access.txt",
    "/home/outline/access.txt",
    "/outline/access.txt",
]

_INSTALL_SCRIPT = (
    "wget -qO- https://raw.githubusercontent.com/Jigsaw-Code/"
    "outline-server/master/src/server_manager/install_scripts/"
    "install_server.sh | bash 2>&1"
)


def _load_pkey(key_str: str):
    from paramiko import RSAKey, DSSKey, ECDSAKey, Ed25519Key
    for cls in (Ed25519Key, ECDSAKey, RSAKey, DSSKey):
        try:
            return cls.from_private_key(io.StringIO(key_str))
        except Exception:
            continue
    raise ValueError(
        "Could not load private key — make sure it is a valid "
        "RSA / ECDSA / Ed25519 / DSS private key."
    )


def _make_client(
    host: str,
    port: int,
    username: str,
    password: str | None,
    private_key_str: str | None,
) -> paramiko.SSHClient:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    connect_kwargs = dict(
        hostname=host,
        port=port,
        username=username,
        timeout=20,
        look_for_keys=False,
        allow_agent=False,
    )
    if private_key_str:
        connect_kwargs["pkey"] = _load_pkey(private_key_str)
    else:
        connect_kwargs["password"] = password

    client.connect(**connect_kwargs)
    return client


def test_ssh(
    host: str,
    port: int,
    username: str,
    password: str | None = None,
    private_key_str: str | None = None,
) -> tuple[bool, str]:
    try:
        c = _make_client(host, port, username, password, private_key_str)
        c.close()
        return True, ""
    except Exception as e:
        return False, str(e)


def discover_outline(
    host: str,
    port: int,
    username: str,
    password: str | None = None,
    private_key_str: str | None = None,
) -> tuple[str, str]:
    """
    SSH in, read existing Outline access file, return (api_url, cert_sha256).
    Raises RuntimeError on failure.
    """
    client = _make_client(host, port, username, password, private_key_str)
    try:
        content = None

        for path in _ACCESS_PATHS:
            for cmd in (f"cat {path} 2>/dev/null",
                        f"sudo cat {path} 2>/dev/null"):
                _, stdout, _ = client.exec_command(cmd)
                out = stdout.read().decode("utf-8", errors="replace").strip()
                if out:
                    content = out
                    break
            if content:
                break

        if not content:
            _, stdout, _ = client.exec_command(
                "find / -maxdepth 6 -name 'access.txt' 2>/dev/null "
                "| xargs grep -l 'apiUrl' 2>/dev/null | head -1"
            )
            found_path = stdout.read().decode("utf-8", errors="replace").strip()
            if found_path:
                _, stdout2, _ = client.exec_command(
                    f"cat {found_path} 2>/dev/null || sudo cat {found_path} 2>/dev/null"
                )
                out2 = stdout2.read().decode("utf-8", errors="replace").strip()
                if out2:
                    content = out2

        if not content:
            raise RuntimeError(
                "Outline access file not found on the VPS.\n"
                "Make sure Outline VPN Server is installed.\n"
                "Install: https://getoutline.org/get-started/#step-1"
            )

        data = json.loads(content)
        api_url: str = data.get("apiUrl", "")
        cert_sha256: str = data.get("certSha256", "")

        if not api_url or not cert_sha256:
            logger.error(
                "Could not parse Outline credentials (content length=%d, "
                "missing apiUrl=%s, missing certSha256=%s).",
                len(content or ""), not api_url, not cert_sha256,
            )
            raise RuntimeError(
                "Could not parse Outline credentials from the server. "
                "Please verify the Outline VPN Server installation and try again."
            )

        api_url = re.sub(
            r"(https?://)(?:127\.0\.0\.1|localhost)",
            rf"\g<1>{host}",
            api_url,
        )
        return api_url, cert_sha256

    finally:
        client.close()


def provision_outline(
    host: str,
    port: int,
    username: str,
    password: str | None = None,
    private_key_str: str | None = None,
    progress_callback=None,
    timeout: int = 600,
) -> tuple[str, str, str]:
    """
    SSH into a fresh VPS and run the official Outline installation script.

    - progress_callback(text): called periodically with status updates.
    - timeout: max seconds to wait for the install to complete (default 10 min).

    Returns (api_url, cert_sha256, raw_output).
    Raises RuntimeError with a human-readable message on failure.
    """
    client = _make_client(host, port, username, password, private_key_str)
    try:
        if progress_callback:
            progress_callback("📦 Outline install script ကို run နေပါသည်…\n(~5 မိနစ် ကြာနိုင်သည်)")

        transport = client.get_transport()
        channel = transport.open_session()
        channel.set_combine_stderr(True)
        channel.exec_command(_INSTALL_SCRIPT)

        output_lines = []
        deadline = time.time() + timeout
        last_update = time.time()
        dot_count = 0

        while True:
            if time.time() > deadline:
                channel.close()
                raise RuntimeError(
                    f"Install script timed out after {timeout // 60} minutes.\n"
                    "VPS သည် script ကို မပြီးနိုင်ပါ။ Manual install လိုအပ်နိုင်သည်။"
                )

            if channel.recv_ready():
                chunk = channel.recv(4096).decode("utf-8", errors="replace")
                output_lines.append(chunk)

                # Send periodic progress dots every 20 sec
                if progress_callback and (time.time() - last_update) > 20:
                    dot_count += 1
                    progress_callback(
                        f"⏳ Install လုပ်နေဆဲ… {'•' * dot_count}\n"
                        f"({dot_count * 20} seconds ကြာပြီ)"
                    )
                    last_update = time.time()

            if channel.exit_status_ready():
                # Drain remaining output
                while channel.recv_ready():
                    chunk = channel.recv(4096).decode("utf-8", errors="replace")
                    output_lines.append(chunk)
                break

            time.sleep(1)

        exit_code = channel.recv_exit_status()
        full_output = "".join(output_lines)

        if exit_code != 0 and not _find_credentials(full_output, host)[0]:
            snippet = full_output[-800:] if len(full_output) > 800 else full_output
            raise RuntimeError(
                f"Install script exited with code {exit_code}.\n"
                f"Output:\n<code>{snippet}</code>"
            )

        api_url, cert_sha256 = _find_credentials(full_output, host)
        if not api_url or not cert_sha256:
            snippet = full_output[-600:] if len(full_output) > 600 else full_output
            raise RuntimeError(
                "Install finished but credentials not found in output.\n"
                f"Output:\n<code>{snippet}</code>"
            )

        return api_url, cert_sha256, full_output

    finally:
        client.close()


_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def _find_credentials(output: str, host: str) -> tuple[str, str]:
    """
    Parse apiUrl + certSha256 from the Outline installer output.
    The installer prints a JSON line like:
        {"apiUrl":"https://...","certSha256":"..."}
    The line is often wrapped in ANSI color codes, e.g.
        \x1b[1;32m{"apiUrl":...,"certSha256":...}\x1b[0m
    """
    # Strip ANSI color/escape codes from the entire output first.
    clean = _ANSI_RE.sub("", output)

    for line in clean.splitlines():
        line = line.strip()
        if '"apiUrl"' in line and '"certSha256"' in line:
            try:
                # Extract exactly the JSON object (from first { to matching }).
                brace_idx = line.index("{")
                end_idx = line.rindex("}")
                data = json.loads(line[brace_idx:end_idx + 1])
                api_url = data.get("apiUrl", "")
                cert_sha256 = data.get("certSha256", "")
                if api_url and cert_sha256:
                    # Replace loopback address with actual VPS IP
                    api_url = re.sub(
                        r"(https?://)(?:127\.0\.0\.1|localhost)",
                        rf"\g<1>{host}",
                        api_url,
                    )
                    return api_url, cert_sha256
            except Exception:
                continue

    # Fallback: search across the whole cleaned output with a regex.
    m = re.search(
        r'\{[^{}]*"apiUrl"\s*:\s*"[^"]+"[^{}]*"certSha256"\s*:\s*"[^"]+"[^{}]*\}',
        clean,
    )
    if m:
        try:
            data = json.loads(m.group(0))
            api_url = data.get("apiUrl", "")
            cert_sha256 = data.get("certSha256", "")
            if api_url and cert_sha256:
                api_url = re.sub(
                    r"(https?://)(?:127\.0\.0\.1|localhost)",
                    rf"\g<1>{host}",
                    api_url,
                )
                return api_url, cert_sha256
        except Exception:
            pass

    return "", ""
