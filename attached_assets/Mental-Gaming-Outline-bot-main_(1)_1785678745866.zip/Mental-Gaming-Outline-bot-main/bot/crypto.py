"""Transparent at-rest encryption for sensitive DB fields (Fernet / AES-128-CBC + HMAC).

The encryption key is derived from ENCRYPTION_KEY if set, otherwise from
TELEGRAM_BOT_TOKEN. The key is NEVER stored in the database, so a leaked/backed-up
`bot.db` alone cannot reveal SSH passwords, private keys, or Outline API secrets.

Values are tagged with an "enc::" prefix so encrypted and legacy-plaintext values
can coexist during migration and be told apart on read.
"""
import base64
import hashlib
import logging
import os

from cryptography.fernet import Fernet, InvalidToken

logger = logging.getLogger(__name__)

_PREFIX = "enc::"


def _derive_key() -> bytes:
    secret = os.environ.get("ENCRYPTION_KEY") or os.environ.get("TELEGRAM_BOT_TOKEN", "")
    if not secret:
        logger.warning("No ENCRYPTION_KEY/TELEGRAM_BOT_TOKEN set — using insecure fallback key.")
        secret = "outline-bot-insecure-default"
    digest = hashlib.sha256(secret.encode("utf-8")).digest()
    return base64.urlsafe_b64encode(digest)


_fernet = Fernet(_derive_key())


def is_encrypted(value) -> bool:
    return isinstance(value, str) and value.startswith(_PREFIX)


def encrypt(value):
    """Encrypt a string. Returns None/empty unchanged. Idempotent for already-encrypted values."""
    if not value or not isinstance(value, str):
        return value
    if is_encrypted(value):
        return value
    token = _fernet.encrypt(value.encode("utf-8")).decode("ascii")
    return _PREFIX + token


def decrypt(value):
    """Decrypt a value. Legacy plaintext (no prefix) is returned as-is."""
    if not is_encrypted(value):
        return value
    try:
        return _fernet.decrypt(value[len(_PREFIX):].encode("ascii")).decode("utf-8")
    except InvalidToken:
        logger.error("Failed to decrypt a value — wrong key? Returning as-is.")
        return value
