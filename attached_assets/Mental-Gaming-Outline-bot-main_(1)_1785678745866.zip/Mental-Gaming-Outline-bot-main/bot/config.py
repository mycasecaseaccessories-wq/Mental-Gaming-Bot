import os

BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
ADMIN_USER_ID = int(os.environ.get("ADMIN_USER_ID", "0"))
DB_PATH = os.path.join(os.path.dirname(__file__), "data", "bot.db")
FLASK_PORT = int(os.environ.get("PORT", 5000))
CHECK_INTERVAL_MINUTES = 60

_replit_domain = os.environ.get("REPLIT_DEV_DOMAIN", "")
SHARE_BASE_URL = os.environ.get(
    "SHARE_BASE_URL",
    f"https://{_replit_domain}" if _replit_domain else "",
)
