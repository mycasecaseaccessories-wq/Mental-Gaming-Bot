"""Background scheduler: key expiry, auto-renew, warnings, daily report."""
import logging
from datetime import datetime, timedelta

from apscheduler.schedulers.background import BackgroundScheduler

import database as db
import outline_client as oc
import messages as M

logger = logging.getLogger(__name__)

_bot = None
_admin_id = None


def _notify(text: str):
    if _bot and _admin_id:
        try:
            _bot.send_message(_admin_id, text, parse_mode="HTML")
        except Exception as e:
            logger.error(f"Notify failed: {e}")


def _notify_customer(tg_user_id: int, text: str):
    if _bot and tg_user_id:
        try:
            _bot.send_message(tg_user_id, text, parse_mode="HTML")
        except Exception as e:
            logger.warning(f"Customer notify {tg_user_id} failed: {e}")


def _check_keys():
    logger.info("Scheduler: checking keys for expiry/limit/warnings...")
    tracked = db.get_all_tracked_keys()
    now = datetime.utcnow()

    for row in tracked:
        server_id   = row["server_id"]
        key_id      = row["key_id"]
        name        = row["name"] or key_id
        api_url     = row["api_url"]
        cert_sha256 = row["cert_sha256"]
        server_name = row["server_name"] or api_url
        cust_id     = row["customer_tg_id"]

        # ── Check expiry ───────────────────────────────────────────────────
        if row["expiry_date"]:
            try:
                expiry_dt = datetime.fromisoformat(row["expiry_date"])
            except Exception:
                expiry_dt = None

            if expiry_dt:
                days_left = (expiry_dt - now).days

                # Warning: 3 days before expiry
                if 0 < days_left <= 3:
                    _notify(
                        M.KEY_EXPIRY_WARNING.format(
                            server=server_name,
                            name=name,
                            days=days_left,
                            date=expiry_dt.strftime("%Y-%m-%d"),
                        )
                    )
                    if cust_id:
                        _notify_customer(
                            cust_id,
                            M.CUSTOMER_KEY_WARNING.format(name=name, days=days_left),
                        )

                # Expired
                if now >= expiry_dt:
                    auto_renew_days = row["auto_renew_days"] or 0
                    if auto_renew_days > 0:
                        # Auto-renew: extend expiry date, do NOT delete key
                        new_expiry = (expiry_dt + timedelta(days=auto_renew_days)).isoformat()
                        db.set_key_expiry(server_id, key_id, new_expiry)
                        _notify(
                            M.KEY_EXPIRED_RENEWED.format(
                                server=server_name,
                                name=name,
                                days=auto_renew_days,
                                new_expiry=new_expiry[:10],
                            )
                        )
                        logger.info(f"Auto-renewed key {key_id} on server {server_id} by {auto_renew_days}d")
                    else:
                        # No auto-renew: delete key
                        ok = oc.delete_key(api_url, cert_sha256, key_id)
                        if ok:
                            db.delete_key_record_by_vpn_id(server_id, key_id)
                            _notify(
                                M.KEY_EXPIRED_NOTIF.format(
                                    server=server_name, name=name, key_id=key_id
                                )
                            )
                            if cust_id:
                                _notify_customer(
                                    cust_id,
                                    M.CUSTOMER_KEY_EXPIRED.format(name=name),
                                )
                            logger.info(f"Deleted expired key {key_id} on server {server_id}")
                    continue  # skip data limit check for this key

        # ── Check data limit ──────────────────────────────────────────────
        if row["data_limit_gb"]:
            ok_usage, usage, usage_err = oc.get_usage(api_url, cert_sha256)
            if not ok_usage:
                logger.warning(f"Could not fetch usage for server {server_id}: {usage_err}")
                continue
            used_bytes = usage.get(str(key_id), 0) or usage.get(key_id, 0)
            limit_bytes = row["data_limit_gb"] * 1024 ** 3
            if used_bytes >= limit_bytes:
                ok = oc.delete_key(api_url, cert_sha256, key_id)
                if ok:
                    db.delete_key_record_by_vpn_id(server_id, key_id)
                    _notify(
                        M.KEY_LIMIT_NOTIF.format(
                            server=server_name,
                            name=name,
                            key_id=key_id,
                            limit=row["data_limit_gb"],
                        )
                    )
                    if cust_id:
                        _notify_customer(
                            cust_id,
                            M.CUSTOMER_KEY_EXPIRED.format(name=name),
                        )
                    logger.info(f"Deleted over-limit key {key_id} on server {server_id}")


def _daily_traffic_report():
    """Send a daily traffic summary for all servers to the admin."""
    servers = db.get_servers()
    if not servers or not _bot or not _admin_id:
        return

    content = ""
    for server in servers:
        ok, usage, _ = oc.get_usage(server["api_url"], server["cert_sha256"])
        if not ok:
            continue
        keys = db.get_keys_by_server(server["id"])
        if not keys:
            continue
        total = 0
        content += f"🖥️ <b>{server['name']}</b>\n"
        for k in keys:
            used = usage.get(str(k["key_id"]), 0) or usage.get(k["key_id"], 0)
            total += used
            content += M.TRAFFIC_REPORT_ITEM.format(
                name=k["name"] or k["key_id"],
                used=oc.format_bytes(used),
                limit=f"{k['data_limit_gb']} GB" if k["data_limit_gb"] else "—",
            )
        content += M.TRAFFIC_REPORT_TOTAL.format(total=oc.format_bytes(total)) + "\n\n"

    if content:
        _notify(M.DAILY_TRAFFIC_REPORT.format(content=content.strip()))


def start_scheduler(bot, admin_id: int, interval_minutes: int = 60):
    global _bot, _admin_id
    _bot = bot
    _admin_id = admin_id

    scheduler = BackgroundScheduler(daemon=True)
    scheduler.add_job(
        _check_keys,
        trigger="interval",
        minutes=interval_minutes,
        id="check_keys",
        replace_existing=True,
    )
    scheduler.add_job(
        _daily_traffic_report,
        trigger="cron",
        hour=8,
        minute=0,
        id="daily_report",
        replace_existing=True,
    )
    scheduler.start()
    logger.info(f"Scheduler started — key checks every {interval_minutes} min, daily report at 08:00 UTC")
    return scheduler
