"""Entry point: language init → Flask keep-alive + share pages → bot polling."""
import html
import logging
import sys
import threading
import time
from datetime import datetime

import telebot
from flask import Flask, abort, request

import database as db
import handlers
import messages as M
import scheduler as sched
import settings_store as ss
from config import ADMIN_USER_ID, BOT_TOKEN, CHECK_INTERVAL_MINUTES, FLASK_PORT

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

if not BOT_TOKEN:
    logger.error("TELEGRAM_BOT_TOKEN is not set!")
    sys.exit(1)
if not ADMIN_USER_ID:
    logger.error("ADMIN_USER_ID is not set!")
    sys.exit(1)

flask_app = Flask(__name__)

# ── Simple in-memory rate limiter for public routes ──────────────────────────
_RATE_LIMIT_WINDOW = 60      # seconds
_RATE_LIMIT_MAX = 30         # requests per window per IP
_rate_lock = threading.Lock()
_rate_hits: dict[str, list[float]] = {}


def _rate_limited(ip: str) -> bool:
    now = time.time()
    with _rate_lock:
        hits = [t for t in _rate_hits.get(ip, []) if now - t < _RATE_LIMIT_WINDOW]
        hits.append(now)
        _rate_hits[ip] = hits
        return len(hits) > _RATE_LIMIT_MAX


def _client_ip() -> str:
    fwd = request.headers.get("X-Forwarded-For", "")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.remote_addr or "unknown"


def _simple_page(title: str, message: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>{html.escape(title)}</title>
<style>body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
background:#0f172a;color:#e2e8f0;min-height:100vh;display:flex;align-items:center;
justify-content:center;padding:1rem;text-align:center}}
.card{{background:#1e293b;border-radius:16px;padding:2rem;max-width:420px}}
h1{{font-size:1.3rem;margin-bottom:0.75rem;color:#f8fafc}}
p{{color:#94a3b8}}</style></head>
<body><div class="card"><h1>{html.escape(title)}</h1><p>{html.escape(message)}</p></div></body></html>"""


@flask_app.route("/")
def index():
    return "Outline VPN Bot is running! ✅", 200


@flask_app.route("/healthz")
def health():
    return "ok", 200


@flask_app.route("/share/<token>")
def share_page(token: str):
    if _rate_limited(_client_ip()):
        return (_simple_page("Too Many Requests", "Please wait a moment and try again."),
                429, {"Content-Type": "text/html; charset=utf-8"})

    key_rec = db.get_key_by_share_token(token)
    if not key_rec:
        abort(404)

    expiry  = key_rec["expiry_date"]
    if expiry:
        try:
            if datetime.fromisoformat(expiry) < datetime.utcnow():
                return (_simple_page("Link Expired",
                                     "This VPN key has expired. Please contact your admin."),
                        410, {"Content-Type": "text/html; charset=utf-8"})
        except ValueError:
            pass

    name    = html.escape(key_rec["name"] or str(key_rec["key_id"]))
    limit   = key_rec["data_limit_gb"]

    from outline_client import list_keys
    server = db.get_server(key_rec["server_id"])
    access_url = ""
    if server:
        try:
            vpn_keys = list_keys(server["api_url"], server["cert_sha256"])
            for k in vpn_keys:
                if str(k.key_id) == str(key_rec["key_id"]):
                    access_url = k.access_url
                    break
        except Exception:
            pass

    if access_url:
        import outline_client as oc
        import settings_store as ss
        access_url = html.escape(oc.apply_brand(access_url, ss.get_brand()))

    expiry_str = expiry[:10] if expiry else "No expiry"
    limit_str  = f"{limit} GB" if limit else "No limit"
    status_str = "🚫 Disabled" if key_rec["is_disabled"] else "✅ Active"

    page_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>VPN Key — {name}</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: #0f172a;
      color: #e2e8f0;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1rem;
    }}
    .card {{
      background: #1e293b;
      border-radius: 16px;
      padding: 2rem;
      max-width: 520px;
      width: 100%;
      box-shadow: 0 20px 60px rgba(0,0,0,0.5);
    }}
    h1 {{
      font-size: 1.5rem;
      font-weight: 700;
      margin-bottom: 0.25rem;
      color: #f8fafc;
    }}
    .subtitle {{
      color: #94a3b8;
      font-size: 0.9rem;
      margin-bottom: 1.5rem;
    }}
    .info-grid {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.75rem;
      margin-bottom: 1.5rem;
    }}
    .info-item {{
      background: #0f172a;
      border-radius: 10px;
      padding: 0.75rem 1rem;
    }}
    .info-label {{
      font-size: 0.75rem;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 0.25rem;
    }}
    .info-value {{
      font-size: 1rem;
      font-weight: 600;
      color: #f1f5f9;
    }}
    .url-section {{
      background: #0f172a;
      border-radius: 10px;
      padding: 1rem;
      margin-bottom: 1rem;
    }}
    .url-label {{
      font-size: 0.75rem;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 0.5rem;
    }}
    .url-box {{
      font-family: 'Courier New', monospace;
      font-size: 0.8rem;
      color: #a5f3fc;
      word-break: break-all;
      line-height: 1.5;
    }}
    .copy-btn {{
      display: block;
      width: 100%;
      padding: 0.875rem;
      background: #3b82f6;
      color: white;
      border: none;
      border-radius: 10px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
    }}
    .copy-btn:hover {{ background: #2563eb; }}
    .copy-btn.copied {{ background: #10b981; }}
    .footer {{
      text-align: center;
      margin-top: 1.25rem;
      font-size: 0.8rem;
      color: #475569;
    }}
  </style>
</head>
<body>
  <div class="card">
    <h1>🔑 {name}</h1>
    <p class="subtitle">Outline VPN Access Key</p>

    <div class="info-grid">
      <div class="info-item">
        <div class="info-label">📅 Expiry</div>
        <div class="info-value">{expiry_str}</div>
      </div>
      <div class="info-item">
        <div class="info-label">💾 Data Limit</div>
        <div class="info-value">{limit_str}</div>
      </div>
      <div class="info-item" style="grid-column: span 2;">
        <div class="info-label">⚠️ Status</div>
        <div class="info-value">{status_str}</div>
      </div>
    </div>

    {"<div class='url-section'><div class='url-label'>🔗 Access URL (copy into Outline app)</div><div class='url-box' id='access-url'>" + access_url + "</div></div><button class='copy-btn' onclick='copyUrl()'>📋 Copy Access URL</button>" if access_url else "<p style='color:#ef4444;text-align:center'>⚠️ Access URL unavailable. Contact admin.</p>"}

    <div class="footer">Powered by Outline VPN Bot</div>
  </div>
  <script>
    function copyUrl() {{
      const url = document.getElementById('access-url').innerText;
      navigator.clipboard.writeText(url).then(() => {{
        const btn = document.querySelector('.copy-btn');
        btn.textContent = '✅ Copied!';
        btn.classList.add('copied');
        setTimeout(() => {{
          btn.textContent = '📋 Copy Access URL';
          btn.classList.remove('copied');
        }}, 2000);
      }});
    }}
  </script>
</body>
</html>"""
    return page_html, 200, {"Content-Type": "text/html; charset=utf-8"}


def run_flask():
    try:
        from waitress import serve
        logger.info(f"Serving Flask via waitress on port {FLASK_PORT}…")
        serve(flask_app, host="0.0.0.0", port=FLASK_PORT, threads=8,
              ident="Outline VPN Bot")
    except Exception as e:
        logger.error(f"waitress unavailable ({e}); falling back to Flask dev server.")
        flask_app.run(host="0.0.0.0", port=FLASK_PORT, debug=False, use_reloader=False)


def main():
    lang = ss.get_lang()
    M.set_lang(lang)
    logger.info(f"Language: {lang}")

    logger.info("Initializing database…")
    db.init_db()

    logger.info(f"Starting bot for admin: {ADMIN_USER_ID}")
    bot = telebot.TeleBot(BOT_TOKEN, parse_mode=None)
    handlers.register(bot)

    logger.info("Starting scheduler…")
    sched.start_scheduler(bot, ADMIN_USER_ID, CHECK_INTERVAL_MINUTES)

    logger.info(f"Starting Flask on port {FLASK_PORT}…")
    threading.Thread(target=run_flask, daemon=True).start()

    logger.info("Bot polling started.")
    bot.infinity_polling(timeout=30, long_polling_timeout=30)


if __name__ == "__main__":
    main()
