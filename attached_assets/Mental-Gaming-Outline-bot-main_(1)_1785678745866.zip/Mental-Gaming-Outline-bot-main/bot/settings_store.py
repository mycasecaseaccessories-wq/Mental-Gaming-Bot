"""Persistent settings (language preference, etc.) for the single-admin bot."""
import json
import os

_SETTINGS_PATH = os.path.join(os.path.dirname(__file__), "data", "settings.json")


def _load() -> dict:
    try:
        with open(_SETTINGS_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save(data: dict):
    os.makedirs(os.path.dirname(_SETTINGS_PATH), exist_ok=True)
    with open(_SETTINGS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def get_lang() -> str:
    return _load().get("lang", "my")


def set_lang(lang: str):
    d = _load()
    d["lang"] = lang
    _save(d)


def get_brand() -> str:
    """Global brand label appended to access keys (shown in customer's Outline app)."""
    return _load().get("brand", "")


def set_brand(brand: str):
    d = _load()
    d["brand"] = brand
    _save(d)
