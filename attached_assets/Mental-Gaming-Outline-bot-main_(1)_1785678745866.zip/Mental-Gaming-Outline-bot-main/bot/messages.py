"""
Bilingual message strings (Myanmar / English).

Usage anywhere in the codebase:
    import messages as M
    M.WELCOME          # returns string in current language
    M.t("WELCOME")     # explicit lookup
    M.set_lang("en")   # switch language
    M.get_lang()       # current language code
"""

_lang: str = "my"


def set_lang(lang: str):
    global _lang
    _lang = lang if lang in ("my", "en") else "my"


def get_lang() -> str:
    return _lang


def t(key: str, lang: str | None = None) -> str:
    l = lang if lang is not None else _lang
    d = MY if l == "my" else EN
    return d.get(key, MY.get(key, key))


def __getattr__(name: str) -> str:
    return t(name)


# ══════════════════════════════════════════════════════════════════════════
#  MYANMAR (Burmese)
# ══════════════════════════════════════════════════════════════════════════
MY: dict[str, str] = {
    # General
    "WELCOME": (
        "🤖 <b>Outline VPN Bot မှ ကြိုဆိုပါသည်</b>\n\n"
        "📋 ကျေးဇူးပြု၍ အောက်မှ မီနူးကို ရွေးချယ်ပါ။"
    ),
    "ADMIN_ONLY": "⛔ ဤ Bot ကို Admin မဟုတ်သောသူများ အသုံးပြုခွင့် မရှိပါ။",
    "CANCELLED": "❌ လုပ်ဆောင်ချက် ပယ်ဖျက်လိုက်သည်။",
    "ERROR": "⚠️ အမှားတစ်ခု ဖြစ်ပေါ်ခဲ့သည်။",
    "BACK": "🔙 နောက်သို့",
    "CANCEL": "❌ ပယ်ဖျက်",
    "CONFIRM": "✅ အတည်ပြုရန်",
    "NO_RECORDS": "📭 မှတ်တမ်းများ မရှိပါ။",
    # Main Menu
    "MAIN_MENU_TEXT": "🏠 <b>ပင်မ မီနူး</b>\n\nကျေးဇူးပြု၍ ရွေးချယ်ပါ:",
    "BTN_SERVER_MGMT":  "🖥️ ဆာဗာ စီမံခန့်ခွဲမှု",
    "BTN_KEY_MGMT":     "🔑 သော့ စီမံခန့်ခွဲမှု",
    "BTN_LANGUAGE":     "🌐 ဘာသာစကား",
    "BTN_ADMINS":       "👮 Admin စီမံခန့်ခွဲမှု",
    "BTN_CUSTOMERS":    "👥 Customer များ",
    "BTN_BROADCAST":    "📢 Broadcast Message",
    "BTN_BACKUP":       "💾 Backup ယူရန်",
    "BTN_SET_BRAND":    "🏷️ Brand သတ်မှတ်ရန်",
    # Brand
    "BRAND_MENU_TEXT": (
        "🏷️ <b>Brand Label</b>\n\n"
        "လက်ရှိ Brand: <b>{brand}</b>\n\n"
        "ဤ brand သည် customer ရဲ့ Outline app ထဲတွင် key ၏ အမည်အဖြစ် ပေါ်ပါမည်။"
    ),
    "BRAND_NONE": "(မသတ်မှတ်ရသေး)",
    "ASK_BRAND": (
        "🏷️ <b>Brand သတ်မှတ်ခြင်း</b>\n\n"
        "Customer ရဲ့ Outline app ထဲ ပေါ်စေချင်သော စာသားကို ရိုက်ထည့်ပါ။\n\n"
        "ဥပမာ: <code>sellingbyMentalGaming</code>\n\n"
        "ဖျက်သိမ်းရန် — <code>-</code> ရိုက်ပါ။\n"
        "မလုပ်တော့ရန် /cancel"
    ),
    "BRAND_SET_OK": "✅ Brand သတ်မှတ်ပြီးပါပြီ: <b>{brand}</b>",
    "BRAND_CLEARED": "✅ Brand ကို ဖယ်ရှားလိုက်ပါပြီ။",
    # Language menu
    "LANG_MENU_TEXT": "🌐 <b>ဘာသာစကား ရွေးချယ်ပါ</b>",
    "BTN_LANG_MY": "🇲🇲 မြန်မာဘာသာ",
    "BTN_LANG_EN": "🇬🇧 English",
    "LANG_SET": "✅ ဘာသာစကား မြန်မာသို့ ပြောင်းလဲပြီးပြီ။",
    # Server Management
    "SERVER_MENU_TEXT": "🖥️ <b>ဆာဗာ စီမံခန့်ခွဲမှု</b>\n\nကျေးဇူးပြု၍ ရွေးချယ်ပါ:",
    "BTN_ADD_SERVER":    "➕ ဆာဗာ ထည့်သွင်းရန်",
    "BTN_LIST_SERVERS":  "📋 ဆာဗာ စာရင်း",
    "BTN_DELETE_SERVER": "🗑️ ဆာဗာ ဖျက်ရန်",
    "BTN_UFW_MANAGE":    "🔥 Firewall (UFW) စီမံမှု",
    # Server add — type choice
    "ADD_SERVER_TYPE_TEXT": (
        "➕ <b>ဆာဗာ ထည့်သွင်းနည်း ရွေးချယ်ပါ</b>\n\n"
        "🚀 <b>Auto-Provision</b> — Fresh VPS ထဲ Outline ကို အလိုအလျောက် install ပြီး ချိတ်ဆက်မည်\n\n"
        "🖥️ <b>VPS (SSH)</b> — Outline ရှိပြီးသား VPS ကို ရှာဖွေမည်\n\n"
        "🔗 <b>API URL</b> — Outline Manager မှ URL ကို တိုက်ရိုက် ထည့်သွင်းမည်"
    ),
    "BTN_ADD_PROVISION": "🚀 Auto-Provision — Fresh VPS ထဲ Install မည်",
    "BTN_ADD_VPS": "🖥️ VPS (SSH) — ရှာဖွေမည်",
    "BTN_ADD_API": "🔗 API URL — ကိုယ်တိုင် ထည့်သွင်းမည်",
    # Auto-Provision flow
    "ASK_PROVISION_IP": (
        "🚀 <b>Auto-Provision — VPS IP</b>\n\n"
        "Fresh VPS ၏ IP လိပ်စာ ထည့်ပါ:\n"
        "(ဥပမာ: <code>123.45.67.89</code>)\n\n"
        "⚠️ VPS သည် Ubuntu/Debian ဖြစ်ရမည်။ Docker ရှိရမည်။"
    ),
    "ASK_PROVISION_PORT": (
        "🔌 SSH Port ထည့်ပါ:\n\n"
        "(ပုံမှန် <code>22</code> — 22 ကို ပေးပို့ပါ)"
    ),
    "ASK_PROVISION_USER": (
        "👤 SSH Username ထည့်ပါ:\n\n"
        "(ဥပမာ: <code>root</code>)"
    ),
    "PROVISION_CONNECTING": "⏳ VPS သို့ SSH ချိတ်ဆက်နေသည်…",
    "PROVISION_INSTALLING": (
        "⌛ <b>VPS ထဲ Outline install လုပ်နေပါတယ်…</b>\n\n"
        "🔧 Official Outline installer ကို run နေသည်\n"
        "⏰ ၅-၁၀ မိနစ် ကြာနိုင်သည်\n\n"
        "ခဏ စောင့်ပါ…"
    ),
    "PROVISION_PROGRESS": "⏳ <b>Install လုပ်နေဆဲ…</b>\n\n{status}",
    "PROVISION_SUCCESS": (
        "✅ <b>Outline VPN အောင်မြင်စွာ Install ပြီးပါပြီ!</b>\n\n"
        "🖥️ ဆာဗာ: <b>{name}</b>\n"
        "🌐 IP: <code>{host}</code>\n\n"
        "ဆာဗာကို Bot ထဲ ထည့်သွင်းပြီး သော့ ဖန်တီးနိုင်ပြီ။"
    ),
    "PROVISION_FAIL": (
        "❌ <b>Install မအောင်မြင်ပါ</b>\n\n"
        "<code>{error}</code>"
    ),
    # VPS SSH flow
    "ASK_SERVER_NAME": "📝 ဆာဗာ အမည် ထည့်ပါ:\n\n(ဥပမာ: MyVPN-1, SG-Server)",
    "ASK_VPS_IP": (
        "🌐 VPS IP လိပ်စာ သို့မဟုတ် Hostname ထည့်ပါ:\n\n"
        "(ဥပမာ: <code>123.45.67.89</code> သို့မဟုတ် <code>myserver.com</code>)"
    ),
    "ASK_VPS_PORT": (
        "🔌 SSH Port ထည့်ပါ:\n\n"
        "(ပုံမှန်အားဖြင့် <code>22</code> — 22 ကို ပေးပို့ပါ)"
    ),
    "ASK_VPS_USER": (
        "👤 SSH Username ထည့်ပါ:\n\n"
        "(ဥပမာ: <code>root</code> — root ကို ပေးပို့ပါ)"
    ),
    "VPS_AUTH_TEXT": "🔐 <b>Authentication နည်းလမ်း</b> ရွေးချယ်ပါ:",
    "BTN_AUTH_PASSWORD": "🔑 Password",
    "BTN_AUTH_KEY":      "📄 SSH Private Key",
    "ASK_VPS_PASSWORD": "🔐 SSH Password ထည့်ပါ:",
    "ASK_VPS_KEY": (
        "📄 SSH Private Key ကို ကူးထည့်ပါ:\n\n"
        "<code>-----BEGIN ... PRIVATE KEY-----</code> မှ\n"
        "<code>-----END ... PRIVATE KEY-----</code> အထိ အားလုံး ကူးပါ"
    ),
    "VPS_CONNECTING":  "⏳ VPS သို့ ချိတ်ဆက်နေသည်… ခဏစောင့်ပါ",
    "VPS_DISCOVERING": "🔍 Outline VPN ကို VPS ပေါ်တွင် ရှာဖွေနေသည်…",
    "VPS_SSH_FAIL":     "❌ SSH ချိတ်ဆက်မှု မအောင်မြင်ပါ:\n<code>{error}</code>",
    "VPS_OUTLINE_FAIL": "❌ Outline VPN ရှာမတွေ့ပါ:\n<code>{error}</code>",
    "VPS_INVALID_PORT": "⚠️ Port နံပါတ် မှားနေသည်။ 1–65535 ကြားရှိ နံပါတ် ထည့်ပါ။",
    # API URL flow
    "ASK_SERVER_URL": (
        "🔗 Outline API URL ထည့်ပါ:\n\n"
        "ဥပမာ: <code>https://1.2.3.4:12345/xxxxxx</code>\n\n"
        "(Outline Manager မှ 'Share access' ကို နှိပ်၍ ရပါသည်)"
    ),
    "ASK_SERVER_CERT": (
        "🔐 Cert SHA-256 Fingerprint ထည့်ပါ:\n\n"
        "ဥပမာ: <code>AABBCC...</code>\n\n"
        "(JSON ထဲမှ certSha256 တန်ဖိုး)"
    ),
    "SERVER_ADDED":       "✅ ဆာဗာ <b>{name}</b> အောင်မြင်စွာ ထည့်သွင်းပြီးပါပြီ။",
    "SERVER_CONN_FAILED": "❌ Outline API သို့ ချိတ်ဆက်မှု မအောင်မြင်ပါ:\n<code>{error}</code>",
    "SERVER_LIST_HEADER": "🖥️ <b>ဆာဗာ စာရင်း</b> ({count} ခု):\n\n",
    "SERVER_ITEM":        "  🖥️ <b>{name}</b>  [{ctype}]\n  🌐 <code>{host}</code>\n\n",
    "CTYPE_VPS": "VPS/SSH",
    "CTYPE_API": "API URL",
    "NO_SERVERS":           "📭 ဆာဗာများ မရှိသေးပါ။ ဆာဗာ ထည့်သွင်းပါ။",
    "SELECT_SERVER_DELETE": "🗑️ ဖျက်မည့် ဆာဗာကို ရွေးချယ်ပါ:",
    "CONFIRM_DELETE_SERVER": (
        "⚠️ <b>သတိပေးချက်</b>\n\n"
        "<b>{name}</b> ကို ဖျက်မည်ဆိုပါက ၎င်းဆာဗာ၏ သော့မှတ်တမ်းများ အားလုံးလည်း ပျောက်သွားမည်။\n\n"
        "အတည်ပြုပါသလား?"
    ),
    "SERVER_DELETED": "✅ ဆာဗာ <b>{name}</b> ဖျက်လိုက်ပြီ။",
    # Key Management
    "SELECT_SERVER_KEY": "🖥️ ဆာဗာတစ်ခုကို ရွေးချယ်ပါ:",
    "KEY_MENU_TEXT": "🔑 <b>သော့ စီမံခန့်ခွဲမှု</b> — {server}\n\nကျေးဇူးပြု၍ ရွေးချယ်ပါ:",
    "BTN_CREATE_KEY":    "➕ သော့ အသစ် ဖန်တီးရန်",
    "BTN_LIST_KEYS":     "📋 သော့ စာရင်း",
    "BTN_VIEW_KEY":      "🔑 Key ပြန်ကြည့်ရန်",
    "BTN_DELETE_KEY":    "🗑️ သော့ ဖျက်ရန်",
    "BTN_KEY_USAGE":     "📊 Traffic Report",
    "BTN_PAYMENTS":      "💰 ငွေပေးချေမှု မှတ်တမ်း",
    "BTN_SHARE_KEY":     "📤 Share Link",
    "BTN_ASSIGN_CUST":   "👤 Customer သတ်မှတ်ရန်",
    "BTN_SET_DOMAIN":    "🌐 Domain သတ်မှတ်ရန်",
    "BTN_TRAFFIC_ALL":   "📊 ဆာဗာ Traffic Report",
    "ASK_DOMAIN": (
        "🌐 <b>Domain / Hostname သတ်မှတ်ခြင်း</b>\n\n"
        "Key တွေထဲ IP address အစား Domain ပြချင်ရင် domain ထည့်ပါ။\n\n"
        "⚠️ <b>အရေးကြီး:</b> ထို domain ၏ DNS <b>A record</b> သည် ဤ VPS ၏ IP သို့ "
        "ညွှန်ထားရမည် (မဟုတ်ရင် key တွေ အလုပ်မလုပ်ပါ)။\n\n"
        "ဥပမာ: <code>vpn.example.com</code>\n\n"
        "IP သို့ ပြန်ပြောင်းရန် — IP address ကို ရိုက်ထည့်ပါ။\n"
        "ဖျက်သိမ်းရန် /cancel"
    ),
    "DOMAIN_SET_OK": (
        "✅ <b>Domain သတ်မှတ်ပြီးပါပြီ</b>\n\n"
        "Hostname: <code>{host}</code>\n\n"
        "ယခုမှစ၍ ဖန်တီးသော key အသစ်များတွင် ဤ domain ကို အသုံးပြုပါမည်။"
    ),
    "DOMAIN_SET_FAIL": "❌ <b>Domain သတ်မှတ်၍ မရပါ</b>\n\n{error}",
    "ASK_KEY_NAME": "📝 သော့ အမည် ထည့်ပါ:\n\n(ဥပမာ: User1, MyPhone)",
    "ASK_DATA_LIMIT":       "💾 <b>ဒေတာ ကန့်သတ်</b> သတ်မှတ်မည်လား?",
    "BTN_YES_LIMIT":        "✅ ကန့်သတ် သတ်မှတ်မည်",
    "BTN_NO_LIMIT":         "❌ ကန့်သတ် မသတ်မှတ်",
    "ASK_DATA_LIMIT_VALUE": "💾 ဒေတာ ကန့်သတ် ပမာဏ (GB) ထည့်ပါ:\n\n(ဥပမာ: 10 / 50 / 100)",
    "ASK_EXPIRY":           "📅 <b>သက်တမ်း</b> သတ်မှတ်မည်လား?",
    "BTN_1M":       "1 လ",
    "BTN_3M":       "3 လ",
    "BTN_6M":       "6 လ",
    "BTN_1Y":       "1 နှစ်",
    "BTN_NO_EXPIRY": "❌ သက်တမ်း မသတ်မှတ်",
    "ASK_AUTO_RENEW": (
        "🔄 <b>Auto-Renew သတ်မှတ်မည်လား?</b>\n\n"
        "သက်တမ်းကုန်လျှင် အလိုအလျောက် ရက်ပေါင်းဘယ်နှစ်ရက် ထပ်တိုးပေးမည်လဲ?"
    ),
    "BTN_RENEW_30":  "🔄 30 ရက်",
    "BTN_RENEW_90":  "🔄 90 ရက်",
    "BTN_RENEW_365": "🔄 365 ရက်",
    "BTN_NO_RENEW":  "❌ Auto-Renew မလုပ်",
    "ASK_DEVICE_LIMIT": (
        "📱 <b>Device ကန့်သတ်</b> (မှတ်ချက်) သတ်မှတ်မည်လား?\n\n"
        "ဘယ်နှစ်ခု Device သုံးနိုင်သည် (0 = ကန့်သတ်မရှိ):"
    ),
    "INVALID_NUMBER": "⚠️ ကျေးဇူးပြု၍ မှန်ကန်သော ဂဏန်း ထည့်ပါ။",
    "KEY_CREATED": (
        "✅ <b>သော့ အောင်မြင်စွာ ဖန်တီးပြီးပါပြီ!</b>\n\n"
        "📛 အမည်: <b>{name}</b>\n"
        "💾 ဒေတာ ကန့်သတ်: <b>{limit}</b>\n"
        "📅 သက်တမ်း: <b>{expiry}</b>\n"
        "🔄 Auto-Renew: <b>{renew}</b>\n"
        "📱 Device ကန့်သတ်: <b>{devices}</b>\n\n"
        "🔗 <b>Access URL:</b>\n<code>{access_url}</code>\n\n"
        "📤 Share Link: {share_url}"
    ),
    "NO_LIMIT_TEXT":  "ကန့်သတ် မရှိ",
    "NO_EXPIRY_TEXT": "သက်တမ်း ကန့်သတ် မရှိ",
    "NO_RENEW_TEXT":  "မသုံး",
    "NO_DEVICE_LIMIT": "ကန့်သတ် မရှိ",
    "KEY_CREATE_FAIL": "❌ သော့ ဖန်တီးမှု မအောင်မြင်ပါ:\n<code>{error}</code>",
    "KEY_LIST_HEADER": "🔑 <b>သော့ စာရင်း</b> — {server} ({count} ခု):\n\n",
    "KEY_ITEM": (
        "━━━━━━━━━━━━━━━━━━━\n"
        "🔑 <b>{name}</b> (ID: {key_id})\n"
        "💾 ဒေတာ ကန့်သတ်: {limit}\n"
        "📅 သက်တမ်း: {expiry}\n"
        "🔄 Auto-Renew: {renew}\n"
        "📱 Device ကန့်သတ်: {devices}\n"
        "⚠️ အခြေအနေ: {status}\n"
    ),
    "STATUS_ACTIVE":   "✅ အသုံးပြုနိုင်",
    "STATUS_DISABLED": "🚫 ပိတ်ဆို့ထား",
    "SELECT_KEY_DELETE": "🗑️ ဖျက်မည့် သော့ကို ရွေးချယ်ပါ:",
    "CONFIRM_DELETE_KEY": (
        "⚠️ <b>သတိပေးချက်</b>\n\n"
        "သော့ <b>{name}</b> ကို ဖျက်မည်ဆိုပါ ၎င်းသော့ဖြင့် ချိတ်ဆက်ထားသူများ "
        "ဆက်လက် အသုံးပြုနိုင်တော့မည် မဟုတ်ပါ။\n\nအတည်ပြုပါသလား?"
    ),
    "KEY_DELETED":     "✅ သော့ <b>{name}</b> ဖျက်လိုက်ပြီ။",
    "KEY_DELETE_FAIL": "❌ သော့ ဖျက်မှု မအောင်မြင်ပါ။",
    "SELECT_KEY_USAGE": "📊 Traffic Report ကြည့်မည့် သော့ကို ရွေးချယ်ပါ:",
    "KEY_USAGE_INFO": (
        "📊 <b>Traffic Report</b>\n\n"
        "🔑 သော့: <b>{name}</b> (ID: {key_id})\n"
        "📤 အသုံးပြုထားသော ဒေတာ: <b>{used}</b>\n"
        "💾 ဒေတာ ကန့်သတ်: <b>{limit}</b>\n"
        "📅 သက်တမ်း: <b>{expiry}</b>\n"
        "🔄 Auto-Renew: <b>{renew}</b>\n"
        "📱 Device ကန့်သတ်: <b>{devices}</b>\n"
        "⚠️ အခြေအနေ: <b>{status}</b>"
    ),
    "USAGE_FETCH_FAIL": "⚠️ ဆာဗာမှ Traffic ဒေတာ မရနိုင်ပါ။",
    "TRAFFIC_REPORT_HEADER": "📊 <b>Traffic Report</b> — {server}\n\n",
    "TRAFFIC_REPORT_ITEM":   "🔑 <b>{name}</b>: {used} / {limit}\n",
    "TRAFFIC_REPORT_TOTAL":  "\n📈 <b>စုစုပေါင်း:</b> {total}",
    # Share Link
    "SHARE_LINK_TEXT": (
        "📤 <b>Share Link</b>\n\n"
        "🔑 သော့: <b>{name}</b>\n\n"
        "🔗 Customer ကို ဤ link ပေးပို့ပါ:\n"
        "<code>{url}</code>"
    ),
    # View existing key access URL
    "SELECT_KEY_VIEW": "🔑 ကြည့်ရှုမည့် သော့ကို ရွေးချယ်ပါ:",
    "KEY_VIEW_TEXT": (
        "🔑 <b>{name}</b>\n\n"
        "အောက်ပါ key ကို ကူးယူ၍ Outline app ထဲ ထည့်ပါ:\n\n"
        "<code>{url}</code>"
    ),
    "KEY_VIEW_FAIL": "⚠️ ဆာဗာမှ key ကို ပြန်မရနိုင်ပါ။\n\n{error}",
    # Key note / comment (admin only)
    "BTN_EDIT_NOTE":   "📝 Note / မှတ်ချက် ရေးရန်",
    "SELECT_KEY_NOTE": "📝 Note ရေးမည့် သော့ကို ရွေးချယ်ပါ:",
    "ASK_KEY_NOTE": (
        "📝 <b>Note / မှတ်ချက်</b>\n\n"
        "ဤ key အတွက် မှတ်ချက် ရိုက်ထည့်ပါ (admin သာ မြင်ရမည်)။\n\n"
        "ဥပမာ: <code>ကိုအောင် ၊ ၁၀၀၀၀ ကျပ် ၊ 30 ရက်</code>\n\n"
        "ဖျက်ရန် — <code>-</code> ရိုက်ပါ။\n"
        "မလုပ်တော့ရန် /cancel"
    ),
    "NOTE_SET_OK":  "✅ Note သိမ်းဆည်းပြီးပါပြီ။",
    "NOTE_CLEARED": "✅ Note ကို ဖယ်ရှားလိုက်ပါပြီ။",
    "NOTE_LINE":    "📝 မှတ်ချက်: {note}\n",
    # Payment
    "PAYMENT_MENU_TEXT": (
        "💰 <b>ငွေပေးချေမှု မှတ်တမ်း</b> — {name}\n\n"
        "ကျေးဇူးပြု၍ ရွေးချယ်ပါ:"
    ),
    "BTN_ADD_PAYMENT":  "➕ ငွေပေးချေမှု မှတ်တမ်းတင်ရန်",
    "BTN_VIEW_PAYMENTS": "📋 မှတ်တမ်း ကြည့်ရန်",
    "ASK_PAYMENT_AMOUNT": "💰 ငွေပမာဏ ထည့်ပါ (MMK):\n\n(ဥပမာ: 5000 / 10000)",
    "ASK_PAYMENT_NOTE":   "📝 မှတ်ချက် ထည့်ပါ (မထည့်ချင်ရင် <code>-</code> ပို့ပါ):",
    "PAYMENT_ADDED":      "✅ ငွေပေးချေမှု မှတ်တမ်း ထည့်ပြီးပြီ — {amount} MMK",
    "PAYMENT_LIST_HEADER": "💰 <b>ငွေပေးချေမှု မှတ်တမ်း</b> — {name}:\n\n",
    "PAYMENT_ITEM": "💵 <b>{amount} {currency}</b> — {date}\n   📝 {note}\n\n",
    "PAYMENT_TOTAL":      "💰 <b>စုစုပေါင်း:</b> {total} MMK",
    "NO_PAYMENTS":        "📭 ငွေပေးချေမှု မှတ်တမ်း မရှိသေးပါ။",
    # Admin management
    "ADMIN_MENU_TEXT": (
        "👮 <b>Admin စီမံခန့်ခွဲမှု</b>\n\n"
        "ကျေးဇူးပြု၍ ရွေးချယ်ပါ:"
    ),
    "BTN_ADD_ADMIN":    "➕ Admin ထည့်ရန်",
    "BTN_LIST_ADMINS":  "📋 Admin စာရင်း",
    "BTN_REMOVE_ADMIN": "🗑️ Admin ဖျက်ရန်",
    "ASK_ADMIN_ID":     "👤 ထည့်လိုသော Admin ၏ Telegram User ID ထည့်ပါ:\n\n(ဥပမာ: 123456789)",
    "ADMIN_ADDED":      "✅ Admin (ID: {uid}) ထည့်ပြီးပြီ။",
    "ADMIN_ALREADY":    "⚠️ ၎င်း ID သည် Admin ဖြစ်ပြီးသားပါ။",
    "ADMIN_LIST_HEADER": "👮 <b>Admin စာရင်း</b> ({count} ဦး):\n\n",
    "ADMIN_ITEM":        "👤 ID: <code>{uid}</code>  @{username}\n   ထည့်ခဲ့သည်: {date}\n\n",
    "NO_EXTRA_ADMINS":   "📭 ထပ်ဆောင်း Admin မရှိသေးပါ။",
    "SELECT_ADMIN_REMOVE": "🗑️ ဖျက်မည့် Admin ကို ရွေးချယ်ပါ:",
    "ADMIN_REMOVED":     "✅ Admin (ID: {uid}) ဖျက်ပြီးပြီ။",
    "PRIMARY_ADMIN_ONLY": "⛔ ဤ လုပ်ဆောင်ချက်ကို ပင်မ Admin သာ ပြုလုပ်နိုင်သည်။",
    # Customer management
    "CUSTOMER_MENU_TEXT": (
        "👥 <b>Customer စီမံခန့်ခွဲမှု</b>\n\n"
        "ကျေးဇူးပြု၍ ရွေးချယ်ပါ:"
    ),
    "BTN_LIST_CUSTOMERS":   "📋 Customer စာရင်း",
    "BTN_REMOVE_CUSTOMER":  "🗑️ Customer ဖျက်ရန်",
    "CUSTOMER_LIST_HEADER": "👥 <b>Customer စာရင်း</b> ({count} ဦး):\n\n",
    "CUSTOMER_ITEM": (
        "👤 <b>{name}</b> (@{username})\n"
        "   ID: <code>{uid}</code> | မှတ်ပုံတင်: {date}\n\n"
    ),
    "NO_CUSTOMERS": "📭 Customer မရှိသေးပါ။",
    # Assign customer to key
    "SELECT_KEY_ASSIGN": "👤 Customer သတ်မှတ်မည့် သော့ကို ရွေးချယ်ပါ:",
    "ASK_CUSTOMER_TG_ID": (
        "👤 Customer ၏ Telegram User ID ထည့်ပါ:\n\n"
        "(Customer က bot ကို /start ပေးပို့ပြီးမှ ၎င်း ID ရပါမည်)\n"
        "(ဖျက်ချင်ရင် <code>0</code> ထည့်ပါ)"
    ),
    "KEY_ASSIGNED":   "✅ သော့ <b>{key}</b> ကို Customer (ID: {uid}) သို့ သတ်မှတ်ပြီးပြီ။",
    "KEY_UNASSIGNED": "✅ သော့ <b>{key}</b> ၏ Customer သတ်မှတ်ချက် ဖျက်ပြီးပြီ။",
    # Broadcast
    "BROADCAST_TEXT":    "📢 <b>Broadcast Message</b>\n\nCustomer အားလုံးသို့ ပေးပို့မည့် message ထည့်ပါ:",
    "BROADCAST_CONFIRM": "📢 <b>Message ပေးပို့မည်လား?</b>\n\nCustomer <b>{count}</b> ဦးသို့ ပေးပို့မည်:\n\n{preview}",
    "BTN_SEND_NOW":      "📤 ယခု ပေးပို့မည်",
    "BROADCAST_DONE":    "✅ Message ကို Customer <b>{sent}</b> ဦးသို့ ပေးပို့ပြီးပြီ။",
    "BROADCAST_NO_CUST": "⚠️ Customer မရှိသေးပါ။ Customer များ bot ကို /start ပေးပို့ပြီးမှ ပေးပို့နိုင်မည်။",
    # Backup
    "BACKUP_SENDING": "⏳ Database backup ယူနေသည်…",
    "BACKUP_DONE":    "✅ Database backup ပြီးပါပြီ။",
    "BACKUP_FAIL":    "❌ Backup မအောင်မြင်ပါ: {error}",
    # UFW / Firewall
    "UFW_MENU_TEXT": (
        "🔥 <b>Firewall (UFW) စီမံခန့်ခွဲမှု</b>\n\n"
        "ဆာဗာ: <b>{server}</b>\n\nကျေးဇူးပြု၍ ရွေးချယ်ပါ:"
    ),
    "BTN_UFW_STATUS":       "📋 UFW Status ကြည့်ရန်",
    "BTN_UFW_ALLOW_PORT":   "✅ Port ဖွင့်ရန်",
    "BTN_UFW_DENY_PORT":    "🚫 Port ပိတ်ရန်",
    "BTN_UFW_ENABLE":       "🟢 UFW Enable",
    "BTN_UFW_DISABLE":      "🔴 UFW Disable",
    "UFW_SELECT_SERVER":    "🔥 UFW စီမံမည့် ဆာဗာကို ရွေးချယ်ပါ (VPS သာ):",
    "UFW_NO_VPS":           "⚠️ VPS ဆာဗာ မရှိပါ။ SSH ဖြင့် ချိတ်ဆက်ထားသော ဆာဗာ မရှိပါ။",
    "UFW_ASK_SSH_PASS":     "🔐 UFW စီမံရန် SSH Password ထည့်ပါ (session တစ်ခုသာ သုံးမည်):",
    "UFW_ASK_PORT":         "🔌 Port နံပါတ် ထည့်ပါ (ဥပမာ: 80 သို့မဟုတ် 443/tcp):",
    "UFW_RUNNING":          "⏳ UFW command run နေသည်…",
    "UFW_RESULT":           "🔥 <b>UFW Result:</b>\n<code>{output}</code>",
    "UFW_FAIL":             "❌ UFW command မအောင်မြင်ပါ:\n<code>{error}</code>",
    # Scheduler notifications
    "KEY_EXPIRED_NOTIF": (
        "🔔 <b>သက်တမ်း ကုန်ဆုံးခြင်း</b>\n\n"
        "ဆာဗာ: <b>{server}</b>\n"
        "သော့ <b>{name}</b> (ID: {key_id}) ၏ သက်တမ်း ကုန်ဆုံးသောကြောင့် ဖျက်လိုက်ပြီ။"
    ),
    "KEY_EXPIRED_RENEWED": (
        "🔄 <b>Auto-Renew လုပ်ဆောင်ပြီးပြီ</b>\n\n"
        "ဆာဗာ: <b>{server}</b>\n"
        "သော့ <b>{name}</b> ၏ သက်တမ်းကို {days} ရက် ထပ်တိုးပြီး {new_expiry} အထိ သတ်မှတ်ပြီးပြီ။"
    ),
    "KEY_LIMIT_NOTIF": (
        "🔔 <b>ဒေတာ ကန့်သတ် ကျော်လွန်ခြင်း</b>\n\n"
        "ဆာဗာ: <b>{server}</b>\n"
        "သော့ <b>{name}</b> (ID: {key_id}) သည် {limit} GB ကျော်လွန်သောကြောင့် ဖျက်လိုက်ပြီ။"
    ),
    "KEY_EXPIRY_WARNING": (
        "⏰ <b>သက်တမ်း ကုန်တော့မည်</b>\n\n"
        "ဆာဗာ: <b>{server}</b>\n"
        "သော့ <b>{name}</b> ၏ သက်တမ်း {days} ရက်အတွင်း ကုန်မည် ({date})။"
    ),
    "CUSTOMER_KEY_EXPIRED": (
        "🔔 <b>သင်၏ VPN Key သက်တမ်း ကုန်ဆုံးပါပြီ</b>\n\n"
        "သော့ <b>{name}</b> ၏ သက်တမ်း ကုန်ဆုံးပါပြီ။\n"
        "ဆက်သုံးလိုပါက Admin ကို ဆက်သွယ်ပါ။"
    ),
    "CUSTOMER_KEY_WARNING": (
        "⏰ <b>သင်၏ VPN Key သက်တမ်း ကုန်တော့မည်</b>\n\n"
        "သော့ <b>{name}</b> ၏ သက်တမ်း {days} ရက်အတွင်း ကုန်မည်။\n"
        "သက်တမ်းတိုးလိုပါက Admin ကို ဆက်သွယ်ပါ။"
    ),
    "DAILY_TRAFFIC_REPORT": "📊 <b>နေ့စဥ် Traffic Report</b>\n\n{content}",
    # Customer self-service
    "CUSTOMER_WELCOME": (
        "👋 <b>မင်္ဂလာပါ!</b>\n\n"
        "သင်၏ VPN key အချက်အလက်များ ကြည့်ရှုနိုင်ပါသည်။\n"
        "Admin ကသတ်မှတ်ပေးမှသာ ကြည့်နိုင်မည်ဖြစ်ပါသည်။"
    ),
    "CUSTOMER_NO_KEY": (
        "📭 <b>Key မသတ်မှတ်ရသေးပါ</b>\n\n"
        "Admin မှ သင့်အတွက် Key မသတ်မှတ်ရသေးပါ။\n"
        "Admin ကို ဆက်သွယ်ပါ။"
    ),
    "CUSTOMER_KEY_INFO": (
        "🔑 <b>သင်၏ VPN Key</b>\n\n"
        "📛 အမည်: <b>{name}</b>\n"
        "💾 ဒေတာ ကန့်သတ်: <b>{limit}</b>\n"
        "📅 သက်တမ်း: <b>{expiry}</b>\n"
        "⚠️ အခြေအနေ: <b>{status}</b>\n\n"
        "🔗 <b>Access URL:</b>\n<code>{access_url}</code>"
    ),
    # Buttons shared
    "BTN_YES_DELETE": "✅ ဟုတ်ကဲ့ ဖျက်မည်",
    "BTN_NO_DELETE":  "❌ မဖျက်ဘူး",
    "BTN_REFRESH":    "🔄 Refresh",
}

# ══════════════════════════════════════════════════════════════════════════
#  ENGLISH
# ══════════════════════════════════════════════════════════════════════════
EN: dict[str, str] = {
    # General
    "WELCOME": (
        "🤖 <b>Welcome to Outline VPN Bot</b>\n\n"
        "📋 Please choose an option from the menu below."
    ),
    "ADMIN_ONLY": "⛔ This bot is for admins only.",
    "CANCELLED":  "❌ Action cancelled.",
    "ERROR":      "⚠️ An error occurred.",
    "BACK":       "🔙 Back",
    "CANCEL":     "❌ Cancel",
    "CONFIRM":    "✅ Confirm",
    "NO_RECORDS": "📭 No records found.",
    # Main Menu
    "MAIN_MENU_TEXT": "🏠 <b>Main Menu</b>\n\nPlease choose an option:",
    "BTN_SERVER_MGMT": "🖥️ Server Management",
    "BTN_KEY_MGMT":    "🔑 Key Management",
    "BTN_LANGUAGE":    "🌐 Language / ဘာသာစကား",
    "BTN_ADMINS":      "👮 Admin Management",
    "BTN_CUSTOMERS":   "👥 Customers",
    "BTN_BROADCAST":   "📢 Broadcast Message",
    "BTN_BACKUP":      "💾 Backup Now",
    "BTN_SET_BRAND":   "🏷️ Set Brand",
    "BRAND_MENU_TEXT": (
        "🏷️ <b>Brand Label</b>\n\n"
        "Current brand: <b>{brand}</b>\n\n"
        "This brand appears as the key's name inside the customer's Outline app."
    ),
    "BRAND_NONE": "(not set)",
    "ASK_BRAND": (
        "🏷️ <b>Set Brand</b>\n\n"
        "Enter the text you want to show inside the customer's Outline app.\n\n"
        "Example: <code>sellingbyMentalGaming</code>\n\n"
        "To clear — type <code>-</code>.\n"
        "To cancel /cancel"
    ),
    "BRAND_SET_OK":  "✅ Brand has been set: <b>{brand}</b>",
    "BRAND_CLEARED": "✅ Brand has been cleared.",
    # Language menu
    "LANG_MENU_TEXT": "🌐 <b>Select Language</b>",
    "BTN_LANG_MY": "🇲🇲 မြန်မာဘာသာ (Myanmar)",
    "BTN_LANG_EN": "🇬🇧 English",
    "LANG_SET": "✅ Language changed to English.",
    # Server Management
    "SERVER_MENU_TEXT":  "🖥️ <b>Server Management</b>\n\nPlease choose an option:",
    "BTN_ADD_SERVER":    "➕ Add Server",
    "BTN_LIST_SERVERS":  "📋 Server List",
    "BTN_DELETE_SERVER": "🗑️ Delete Server",
    "BTN_UFW_MANAGE":    "🔥 Firewall (UFW)",
    # Server add — type choice
    "ADD_SERVER_TYPE_TEXT": (
        "➕ <b>How would you like to add the server?</b>\n\n"
        "🖥️ <b>VPS (SSH)</b> — Only have your VPS IP & password? "
        "The bot will auto-discover your Outline API credentials.\n\n"
        "🔗 <b>API URL</b> — Paste the URL directly from Outline Manager."
    ),
    "BTN_ADD_VPS": "🖥️ VPS (SSH) — Auto-discover",
    "BTN_ADD_API": "🔗 API URL — Manual entry",
    # VPS SSH flow
    "ASK_SERVER_NAME": "📝 Enter a name for this server:\n\n(e.g. MyVPN-1, SG-Server)",
    "ASK_VPS_IP": (
        "🌐 Enter the VPS IP address or hostname:\n\n"
        "(e.g. <code>123.45.67.89</code> or <code>myserver.com</code>)"
    ),
    "ASK_VPS_PORT": (
        "🔌 Enter SSH port:\n\n"
        "(Default is <code>22</code> — just send <code>22</code>)"
    ),
    "ASK_VPS_USER": (
        "👤 Enter SSH username:\n\n"
        "(e.g. <code>root</code> — just send <code>root</code>)"
    ),
    "VPS_AUTH_TEXT":     "🔐 <b>Choose authentication method:</b>",
    "BTN_AUTH_PASSWORD": "🔑 Password",
    "BTN_AUTH_KEY":      "📄 SSH Private Key",
    "ASK_VPS_PASSWORD":  "🔐 Enter your SSH password:",
    "ASK_VPS_KEY": (
        "📄 Paste your SSH private key:\n\n"
        "Copy everything from <code>-----BEGIN ... PRIVATE KEY-----</code>\n"
        "to <code>-----END ... PRIVATE KEY-----</code>"
    ),
    "VPS_CONNECTING":   "⏳ Connecting to VPS… please wait",
    "VPS_DISCOVERING":  "🔍 Looking for Outline VPN on the VPS…",
    "VPS_SSH_FAIL":     "❌ SSH connection failed:\n<code>{error}</code>",
    "VPS_OUTLINE_FAIL": "❌ Could not find Outline VPN:\n<code>{error}</code>",
    "VPS_INVALID_PORT": "⚠️ Invalid port number. Enter a number between 1 and 65535.",
    # API URL flow
    "ASK_SERVER_URL": (
        "🔗 Enter the Outline API URL:\n\n"
        "e.g. <code>https://1.2.3.4:12345/xxxxxx</code>\n\n"
        "(From Outline Manager → Share access)"
    ),
    "ASK_SERVER_CERT": (
        "🔐 Enter the Cert SHA-256 fingerprint:\n\n"
        "e.g. <code>AABBCC...</code>\n\n"
        "(The certSha256 value from the JSON)"
    ),
    "SERVER_ADDED":       "✅ Server <b>{name}</b> added successfully.",
    "SERVER_CONN_FAILED": "❌ Could not connect to Outline API:\n<code>{error}</code>",
    "SERVER_LIST_HEADER": "🖥️ <b>Server List</b> ({count} servers):\n\n",
    "SERVER_ITEM":        "  🖥️ <b>{name}</b>  [{ctype}]\n  🌐 <code>{host}</code>\n\n",
    "CTYPE_VPS": "VPS/SSH",
    "CTYPE_API": "API URL",
    "NO_SERVERS":            "📭 No servers added yet. Add a server first.",
    "SELECT_SERVER_DELETE":  "🗑️ Select the server to delete:",
    "CONFIRM_DELETE_SERVER": (
        "⚠️ <b>Warning</b>\n\n"
        "Deleting <b>{name}</b> will also remove all key records for that server.\n\n"
        "Are you sure?"
    ),
    "SERVER_DELETED": "✅ Server <b>{name}</b> deleted.",
    # Key Management
    "SELECT_SERVER_KEY": "🖥️ Select a server:",
    "KEY_MENU_TEXT": "🔑 <b>Key Management</b> — {server}\n\nPlease choose an option:",
    "BTN_CREATE_KEY":  "➕ Create New Key",
    "BTN_LIST_KEYS":   "📋 Key List",
    "BTN_VIEW_KEY":    "🔑 View Key",
    "BTN_DELETE_KEY":  "🗑️ Delete Key",
    "BTN_KEY_USAGE":   "📊 Traffic Report",
    "BTN_PAYMENTS":    "💰 Payment Records",
    "BTN_SHARE_KEY":   "📤 Share Link",
    "BTN_ASSIGN_CUST": "👤 Assign Customer",
    "BTN_SET_DOMAIN":  "🌐 Set Domain",
    "BTN_TRAFFIC_ALL": "📊 Server Traffic Report",
    "ASK_DOMAIN": (
        "🌐 <b>Set Domain / Hostname</b>\n\n"
        "Enter a domain to show in keys instead of the IP address.\n\n"
        "⚠️ <b>Important:</b> The domain's DNS <b>A record</b> must point to this "
        "VPS's IP (otherwise the keys will not work).\n\n"
        "Example: <code>vpn.example.com</code>\n\n"
        "To switch back to IP — enter the IP address.\n"
        "To cancel /cancel"
    ),
    "DOMAIN_SET_OK": (
        "✅ <b>Domain has been set</b>\n\n"
        "Hostname: <code>{host}</code>\n\n"
        "New keys created from now on will use this domain."
    ),
    "DOMAIN_SET_FAIL": "❌ <b>Could not set domain</b>\n\n{error}",
    "ASK_KEY_NAME":         "📝 Enter a name for the key:\n\n(e.g. User1, MyPhone)",
    "ASK_DATA_LIMIT":       "💾 <b>Set a data limit?</b>",
    "BTN_YES_LIMIT":        "✅ Set Limit",
    "BTN_NO_LIMIT":         "❌ No Limit",
    "ASK_DATA_LIMIT_VALUE": "💾 Enter data limit in GB:\n\n(e.g. 10 / 50 / 100)",
    "ASK_EXPIRY":           "📅 <b>Set an expiry date?</b>",
    "BTN_1M":       "1 Month",
    "BTN_3M":       "3 Months",
    "BTN_6M":       "6 Months",
    "BTN_1Y":       "1 Year",
    "BTN_NO_EXPIRY": "❌ No Expiry",
    "ASK_AUTO_RENEW": (
        "🔄 <b>Set Auto-Renew?</b>\n\n"
        "How many days to auto-extend when key expires?"
    ),
    "BTN_RENEW_30":  "🔄 30 days",
    "BTN_RENEW_90":  "🔄 90 days",
    "BTN_RENEW_365": "🔄 365 days",
    "BTN_NO_RENEW":  "❌ No Auto-Renew",
    "ASK_DEVICE_LIMIT": (
        "📱 <b>Device Limit</b> (informational):\n\n"
        "Max devices allowed (0 = unlimited):"
    ),
    "INVALID_NUMBER": "⚠️ Please enter a valid number.",
    "KEY_CREATED": (
        "✅ <b>Key created successfully!</b>\n\n"
        "📛 Name: <b>{name}</b>\n"
        "💾 Data Limit: <b>{limit}</b>\n"
        "📅 Expiry: <b>{expiry}</b>\n"
        "🔄 Auto-Renew: <b>{renew}</b>\n"
        "📱 Device Limit: <b>{devices}</b>\n\n"
        "🔗 <b>Access URL:</b>\n<code>{access_url}</code>\n\n"
        "📤 Share Link: {share_url}"
    ),
    "NO_LIMIT_TEXT":   "No limit",
    "NO_EXPIRY_TEXT":  "No expiry",
    "NO_RENEW_TEXT":   "Disabled",
    "NO_DEVICE_LIMIT": "Unlimited",
    "KEY_CREATE_FAIL": "❌ Key creation failed:\n<code>{error}</code>",
    "KEY_LIST_HEADER": "🔑 <b>Key List</b> — {server} ({count} keys):\n\n",
    "KEY_ITEM": (
        "━━━━━━━━━━━━━━━━━━━\n"
        "🔑 <b>{name}</b> (ID: {key_id})\n"
        "💾 Data Limit: {limit}\n"
        "📅 Expiry: {expiry}\n"
        "🔄 Auto-Renew: {renew}\n"
        "📱 Device Limit: {devices}\n"
        "⚠️ Status: {status}\n"
    ),
    "STATUS_ACTIVE":   "✅ Active",
    "STATUS_DISABLED": "🚫 Disabled",
    "SELECT_KEY_DELETE": "🗑️ Select the key to delete:",
    "CONFIRM_DELETE_KEY": (
        "⚠️ <b>Warning</b>\n\n"
        "Deleting key <b>{name}</b> will immediately disconnect users on this key.\n\n"
        "Are you sure?"
    ),
    "KEY_DELETED":     "✅ Key <b>{name}</b> deleted.",
    "KEY_DELETE_FAIL": "❌ Key deletion failed.",
    "SELECT_KEY_USAGE": "📊 Select key to view traffic report:",
    "KEY_USAGE_INFO": (
        "📊 <b>Traffic Report</b>\n\n"
        "🔑 Key: <b>{name}</b> (ID: {key_id})\n"
        "📤 Data Used: <b>{used}</b>\n"
        "💾 Data Limit: <b>{limit}</b>\n"
        "📅 Expiry: <b>{expiry}</b>\n"
        "🔄 Auto-Renew: <b>{renew}</b>\n"
        "📱 Device Limit: <b>{devices}</b>\n"
        "⚠️ Status: <b>{status}</b>"
    ),
    "USAGE_FETCH_FAIL":      "⚠️ Could not fetch traffic data from server.",
    "TRAFFIC_REPORT_HEADER": "📊 <b>Traffic Report</b> — {server}\n\n",
    "TRAFFIC_REPORT_ITEM":   "🔑 <b>{name}</b>: {used} / {limit}\n",
    "TRAFFIC_REPORT_TOTAL":  "\n📈 <b>Total:</b> {total}",
    # Share Link
    "SHARE_LINK_TEXT": (
        "📤 <b>Share Link</b>\n\n"
        "🔑 Key: <b>{name}</b>\n\n"
        "🔗 Send this link to your customer:\n"
        "<code>{url}</code>"
    ),
    # View existing key access URL
    "SELECT_KEY_VIEW": "🔑 Select the key to view:",
    "KEY_VIEW_TEXT": (
        "🔑 <b>{name}</b>\n\n"
        "Copy the key below and paste it into the Outline app:\n\n"
        "<code>{url}</code>"
    ),
    "KEY_VIEW_FAIL": "⚠️ Could not fetch the key from the server.\n\n{error}",
    # Key note / comment (admin only)
    "BTN_EDIT_NOTE":   "📝 Add Note",
    "SELECT_KEY_NOTE": "📝 Select the key to add a note to:",
    "ASK_KEY_NOTE": (
        "📝 <b>Note / Comment</b>\n\n"
        "Enter a note for this key (visible to admins only).\n\n"
        "Example: <code>John, 10000 MMK, 30 days</code>\n\n"
        "To clear — type <code>-</code>.\n"
        "To cancel /cancel"
    ),
    "NOTE_SET_OK":  "✅ Note has been saved.",
    "NOTE_CLEARED": "✅ Note has been cleared.",
    "NOTE_LINE":    "📝 Note: {note}\n",
    # Payment
    "PAYMENT_MENU_TEXT": (
        "💰 <b>Payment Records</b> — {name}\n\n"
        "Please choose an option:"
    ),
    "BTN_ADD_PAYMENT":    "➕ Add Payment Record",
    "BTN_VIEW_PAYMENTS":  "📋 View Records",
    "ASK_PAYMENT_AMOUNT": "💰 Enter payment amount (MMK):\n\n(e.g. 5000 / 10000)",
    "ASK_PAYMENT_NOTE":   "📝 Enter a note (send <code>-</code> to skip):",
    "PAYMENT_ADDED":      "✅ Payment recorded — {amount} MMK",
    "PAYMENT_LIST_HEADER": "💰 <b>Payment Records</b> — {name}:\n\n",
    "PAYMENT_ITEM":        "💵 <b>{amount} {currency}</b> — {date}\n   📝 {note}\n\n",
    "PAYMENT_TOTAL":       "💰 <b>Total:</b> {total} MMK",
    "NO_PAYMENTS":         "📭 No payment records yet.",
    # Admin management
    "ADMIN_MENU_TEXT": (
        "👮 <b>Admin Management</b>\n\n"
        "Please choose an option:"
    ),
    "BTN_ADD_ADMIN":    "➕ Add Admin",
    "BTN_LIST_ADMINS":  "📋 Admin List",
    "BTN_REMOVE_ADMIN": "🗑️ Remove Admin",
    "ASK_ADMIN_ID":     "👤 Enter the Telegram User ID of the new admin:\n\n(e.g. 123456789)",
    "ADMIN_ADDED":      "✅ Admin (ID: {uid}) added.",
    "ADMIN_ALREADY":    "⚠️ This ID is already an admin.",
    "ADMIN_LIST_HEADER": "👮 <b>Admin List</b> ({count} admins):\n\n",
    "ADMIN_ITEM":        "👤 ID: <code>{uid}</code>  @{username}\n   Added: {date}\n\n",
    "NO_EXTRA_ADMINS":   "📭 No extra admins yet.",
    "SELECT_ADMIN_REMOVE": "🗑️ Select admin to remove:",
    "ADMIN_REMOVED":       "✅ Admin (ID: {uid}) removed.",
    "PRIMARY_ADMIN_ONLY":  "⛔ Only the primary admin can perform this action.",
    # Customer management
    "CUSTOMER_MENU_TEXT": (
        "👥 <b>Customer Management</b>\n\n"
        "Please choose an option:"
    ),
    "BTN_LIST_CUSTOMERS":   "📋 Customer List",
    "BTN_REMOVE_CUSTOMER":  "🗑️ Remove Customer",
    "CUSTOMER_LIST_HEADER": "👥 <b>Customer List</b> ({count} customers):\n\n",
    "CUSTOMER_ITEM": (
        "👤 <b>{name}</b> (@{username})\n"
        "   ID: <code>{uid}</code> | Joined: {date}\n\n"
    ),
    "NO_CUSTOMERS": "📭 No customers yet.",
    # Assign customer to key
    "SELECT_KEY_ASSIGN": "👤 Select the key to assign a customer to:",
    "ASK_CUSTOMER_TG_ID": (
        "👤 Enter the customer's Telegram User ID:\n\n"
        "(The customer must send /start to the bot first)\n"
        "(Send <code>0</code> to unassign)"
    ),
    "KEY_ASSIGNED":   "✅ Key <b>{key}</b> assigned to customer (ID: {uid}).",
    "KEY_UNASSIGNED": "✅ Customer assignment removed from key <b>{key}</b>.",
    # Broadcast
    "BROADCAST_TEXT":    "📢 <b>Broadcast Message</b>\n\nEnter the message to send to all customers:",
    "BROADCAST_CONFIRM": "📢 <b>Send this message?</b>\n\nWill send to <b>{count}</b> customer(s):\n\n{preview}",
    "BTN_SEND_NOW":      "📤 Send Now",
    "BROADCAST_DONE":    "✅ Message sent to <b>{sent}</b> customer(s).",
    "BROADCAST_NO_CUST": "⚠️ No customers yet. Customers must send /start to the bot first.",
    # Backup
    "BACKUP_SENDING": "⏳ Creating database backup…",
    "BACKUP_DONE":    "✅ Database backup complete.",
    "BACKUP_FAIL":    "❌ Backup failed: {error}",
    # UFW / Firewall
    "UFW_MENU_TEXT": (
        "🔥 <b>Firewall (UFW) Management</b>\n\n"
        "Server: <b>{server}</b>\n\nPlease choose an option:"
    ),
    "BTN_UFW_STATUS":     "📋 UFW Status",
    "BTN_UFW_ALLOW_PORT": "✅ Allow Port",
    "BTN_UFW_DENY_PORT":  "🚫 Deny Port",
    "BTN_UFW_ENABLE":     "🟢 Enable UFW",
    "BTN_UFW_DISABLE":    "🔴 Disable UFW",
    "UFW_SELECT_SERVER":  "🔥 Select a VPS server for UFW management:",
    "UFW_NO_VPS":         "⚠️ No VPS servers found. Only SSH-connected servers support UFW.",
    "UFW_ASK_SSH_PASS":   "🔐 Enter SSH password for UFW management (session only, not stored):",
    "UFW_ASK_PORT":       "🔌 Enter port number or rule (e.g. 80 or 443/tcp):",
    "UFW_RUNNING":        "⏳ Running UFW command…",
    "UFW_RESULT":         "🔥 <b>UFW Result:</b>\n<code>{output}</code>",
    "UFW_FAIL":           "❌ UFW command failed:\n<code>{error}</code>",
    # Scheduler notifications
    "KEY_EXPIRED_NOTIF": (
        "🔔 <b>Key Expired</b>\n\n"
        "Server: <b>{server}</b>\n"
        "Key <b>{name}</b> (ID: {key_id}) has expired and was deleted."
    ),
    "KEY_EXPIRED_RENEWED": (
        "🔄 <b>Auto-Renew Completed</b>\n\n"
        "Server: <b>{server}</b>\n"
        "Key <b>{name}</b> renewed for {days} days. New expiry: {new_expiry}."
    ),
    "KEY_LIMIT_NOTIF": (
        "🔔 <b>Data Limit Exceeded</b>\n\n"
        "Server: <b>{server}</b>\n"
        "Key <b>{name}</b> (ID: {key_id}) exceeded {limit} GB and was deleted."
    ),
    "KEY_EXPIRY_WARNING": (
        "⏰ <b>Key Expiring Soon</b>\n\n"
        "Server: <b>{server}</b>\n"
        "Key <b>{name}</b> expires in {days} day(s) on {date}."
    ),
    "CUSTOMER_KEY_EXPIRED": (
        "🔔 <b>Your VPN Key has expired</b>\n\n"
        "Key <b>{name}</b> has expired.\n"
        "Contact the admin to renew."
    ),
    "CUSTOMER_KEY_WARNING": (
        "⏰ <b>Your VPN Key is expiring soon</b>\n\n"
        "Key <b>{name}</b> expires in {days} day(s).\n"
        "Contact the admin to renew."
    ),
    "DAILY_TRAFFIC_REPORT": "📊 <b>Daily Traffic Report</b>\n\n{content}",
    # Customer self-service
    "CUSTOMER_WELCOME": (
        "👋 <b>Welcome!</b>\n\n"
        "You can check your VPN key status here.\n"
        "The admin must assign a key to you first."
    ),
    "CUSTOMER_NO_KEY": (
        "📭 <b>No key assigned</b>\n\n"
        "The admin has not assigned a key to you yet.\n"
        "Please contact the admin."
    ),
    "CUSTOMER_KEY_INFO": (
        "🔑 <b>Your VPN Key</b>\n\n"
        "📛 Name: <b>{name}</b>\n"
        "💾 Data Limit: <b>{limit}</b>\n"
        "📅 Expiry: <b>{expiry}</b>\n"
        "⚠️ Status: <b>{status}</b>\n\n"
        "🔗 <b>Access URL:</b>\n<code>{access_url}</code>"
    ),
    # Buttons shared
    "BTN_YES_DELETE": "✅ Yes, Delete",
    "BTN_NO_DELETE":  "❌ Cancel",
    "BTN_REFRESH":    "🔄 Refresh",
}
