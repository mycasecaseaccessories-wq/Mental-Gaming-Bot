"""Thin wrapper around outline-vpn-api with error handling."""
from urllib.parse import quote

from outline_vpn.outline_vpn import OutlineVPN


def apply_brand(access_url: str, brand: str) -> str:
    """Append a brand label as the URL fragment so it shows as the key name
    inside the customer's Outline app. Replaces any existing fragment."""
    if not brand or not access_url:
        return access_url
    base = access_url.split("#", 1)[0]
    return f"{base}#{quote(brand)}"


def get_client(api_url: str, cert_sha256: str) -> OutlineVPN:
    return OutlineVPN(api_url=api_url, cert_sha256=cert_sha256)


def test_connection(api_url: str, cert_sha256: str) -> tuple[bool, str]:
    """Return (ok, error_message)."""
    try:
        client = get_client(api_url, cert_sha256)
        client.get_keys()
        return True, ""
    except Exception as e:
        return False, str(e)


def list_keys(api_url: str, cert_sha256: str):
    """Return list of OutlineKey objects or raise."""
    client = get_client(api_url, cert_sha256)
    return client.get_keys()


def create_key(api_url: str, cert_sha256: str, name: str, data_limit_bytes: int = None):
    """Create a new key. Returns OutlineKey."""
    client = get_client(api_url, cert_sha256)
    key = client.create_key(name=name)
    if data_limit_bytes is not None:
        client.add_data_limit(key_id=key.key_id, limit_bytes=data_limit_bytes)
    return key


def delete_key(api_url: str, cert_sha256: str, key_id: str) -> bool:
    try:
        client = get_client(api_url, cert_sha256)
        client.delete_key(key_id=key_id)
        return True
    except Exception:
        return False


def rename_key(api_url: str, cert_sha256: str, key_id: str, name: str) -> bool:
    try:
        client = get_client(api_url, cert_sha256)
        client.rename_key(key_id=key_id, name=name)
        return True
    except Exception:
        return False


def set_data_limit(api_url: str, cert_sha256: str, key_id: str, limit_bytes: int) -> bool:
    try:
        client = get_client(api_url, cert_sha256)
        client.add_data_limit(key_id=key_id, limit_bytes=limit_bytes)
        return True
    except Exception:
        return False


def remove_data_limit(api_url: str, cert_sha256: str, key_id: str) -> bool:
    try:
        client = get_client(api_url, cert_sha256)
        client.delete_data_limit(key_id=key_id)
        return True
    except Exception:
        return False


def get_key_access_url(api_url: str, cert_sha256: str, key_id: str) -> tuple[bool, str, str]:
    """Return (ok, access_url, error) for a single key."""
    try:
        client = get_client(api_url, cert_sha256)
        key = client.get_key(key_id)
        url = getattr(key, "access_url", "") or ""
        if not url:
            return False, "", "access_url not found"
        return True, url, ""
    except Exception as e:
        return False, "", str(e)


def set_hostname(api_url: str, cert_sha256: str, hostname: str) -> tuple[bool, str]:
    """Set the hostname/domain used in generated access keys. Returns (ok, error)."""
    try:
        client = get_client(api_url, cert_sha256)
        client.set_hostname(hostname)
        return True, ""
    except Exception as e:
        return False, str(e)


def get_usage(api_url: str, cert_sha256: str) -> tuple[bool, dict, str]:
    """Return (ok, {key_id: bytes_transferred}, error_message)."""
    try:
        client = get_client(api_url, cert_sha256)
        data = client.get_transferred_data()
        if isinstance(data, dict):
            return True, data.get("bytesTransferredByUserId", {}), ""
        if hasattr(data, "bytesTransferredByUserId"):
            return True, data.bytesTransferredByUserId or {}, ""
        return True, {}, ""
    except Exception as e:
        return False, {}, str(e)


def format_bytes(b: int) -> str:
    if b is None:
        return "0 B"
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if b < 1024:
            return f"{b:.2f} {unit}"
        b /= 1024
    return f"{b:.2f} PB"
