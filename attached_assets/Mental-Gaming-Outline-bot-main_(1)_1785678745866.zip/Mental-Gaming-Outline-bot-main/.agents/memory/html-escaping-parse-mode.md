---
name: HTML escaping with parse_mode=HTML
description: Policy + pitfalls for escaping untrusted values rendered as Telegram HTML or in the public /share page.
---

# HTML escaping with parse_mode="HTML"

The bot sends messages with `parse_mode="HTML"` and serves a public `/share/<token>` page. Any
untrusted value interpolated into those strings must be `html.escape`d, or it's a markup/XSS
injection vector.

**Why:** customer names/usernames are attacker-controlled (from Telegram); admin-set key names,
notes, and the brand fragment can accidentally break rendering; the `/share` page is fully public,
so an unescaped stored key name is stored-XSS.

**How to apply:** escape at every render site — customer/key lists, notes, customer self-service
key info (name + branded access_url), broadcast text, and the share page (name + access_url). When
adding a new HTML-rendered message or web surface, escape the interpolated values.

**Pitfall:** never name a local variable `html` in a function that also calls `html.escape(...)` —
Python local-scope rules turn the module calls into `UnboundLocalError`.
