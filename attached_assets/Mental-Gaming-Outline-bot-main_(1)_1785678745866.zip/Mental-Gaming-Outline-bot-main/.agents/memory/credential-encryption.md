---
name: Credential encryption at rest
description: Decision + pitfalls for Fernet-encrypting server SSH/API credentials in the bot's SQLite DB.
---

# Credential encryption at rest

Server secret fields (api_url, cert_sha256, ssh_password, ssh_key) are Fernet-encrypted before
storage. The key derives from `ENCRYPTION_KEY`, or falls back to deriving from the bot token.
Ciphertext carries an `enc::` prefix; decrypt passes legacy plaintext through unchanged. The key
is never stored in the DB (so the Telegram DB-backup feature can't leak it).

**Key-derivation tradeoff / why:** with `ENCRYPTION_KEY` unset the key comes from the bot token,
so **rotating the token silently breaks decryption of already-stored creds** — decrypt returns the
value as-is on InvalidToken rather than erroring. Always set `ENCRYPTION_KEY` explicitly in
production. Secrets can only be set via the environment-secrets skill, never programmatically.

**How to apply — decrypt on EVERY read path, including JOINs.** It's easy to add a new query that
selects the server secret columns and forget to decrypt; the scheduler/Outline calls then receive
`enc::...` and fail silently. Whenever you add a read that returns these fields, decrypt its rows.
