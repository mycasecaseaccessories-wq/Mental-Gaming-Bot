---
name: Access-URL display paths (Telegram bot)
description: All the places an Outline ss:// access URL is shown to users; any URL transform must touch every one.
---

Any transform applied to a key's `ss://` access URL (e.g. the brand `#fragment` label) must be applied at EVERY display path, or some users get an inconsistent/untransformed URL.

**Why:** The brand feature was first added only to key-creation, admin view, and the `/share` page. Code review caught that the two *customer self-service* paths still emitted the raw URL.

**How to apply:** The access-URL surfaces in `bot/` are:
- `handlers._finish_key_creation` (key created result)
- `handlers` `key:view` callback (admin views a key)
- `handlers.handle_start` (customer /start shows their key)
- `handlers` `cust:my_key` callback (customer self-service)
- `main.share_page` (`/share/<token>` public page)
Grep for `access_url` / `.access_url` across `bot/handlers.py` and `bot/main.py` when changing URL rendering.
