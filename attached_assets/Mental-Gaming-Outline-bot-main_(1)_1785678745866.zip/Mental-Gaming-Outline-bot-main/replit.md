# Outline VPN Management Telegram Bot

An admin-only Telegram bot for managing Outline VPN servers and access keys, with a full Myanmar (Burmese) language UI.

## Run & Operate

- `cd bot && python3 main.py` — run the Telegram bot (managed via "Telegram Bot" workflow)
- The bot polls Telegram every 30 seconds and auto-restarts via the workflow.

## Required Secrets

Set in Replit Secrets:
- `TELEGRAM_BOT_TOKEN` — from @BotFather
- `ADMIN_USER_ID` — your numeric Telegram user ID (get from @userinfobot)

## Stack

- Python 3.11
- `pyTelegramBotAPI` — Telegram bot framework (polling mode)
- `outline-vpn-api` — Outline VPN server communication
- `APScheduler` — background job for key expiry / data-limit enforcement
- `Flask` — keep-alive HTTP endpoint on port 5000
- SQLite — local persistence (`bot/data/bot.db`)

## Where things live

```
bot/
├── main.py          — Entry point: Flask keep-alive + bot polling
├── config.py        — Reads env vars (BOT_TOKEN, ADMIN_USER_ID)
├── database.py      — SQLite schema + CRUD for servers and keys
├── outline_client.py — Wrapper around outline-vpn-api
├── messages.py      — All Myanmar (Burmese) UI strings
├── keyboards.py     — Inline keyboard builders
├── handlers.py      — All bot command + callback handlers
├── scheduler.py     — APScheduler: checks expiry + data limits hourly
├── requirements.txt — Python dependencies
└── data/            — SQLite DB (auto-created, gitignored)
```

## Features

1. **Admin-only** — bot ignores all non-admin users (enforced by ADMIN_USER_ID)
2. **Server Management** — add/list/delete multiple Outline servers (API URL + cert SHA256)
3. **Key Management** — create keys with optional data limit (GB) and expiry (1/3/6 months, 1 year)
4. **Usage Tracking** — view per-key data usage from the Outline server in real-time
5. **Auto-enforcement** — scheduler checks every hour; expired or over-limit keys are automatically deleted and the admin is notified
6. **Myanmar UI** — all menus, buttons, and messages are in Burmese script

## Architecture decisions

- Polling mode (not webhook) — simpler on Replit, no public HTTPS setup needed
- SQLite (not PostgreSQL) — lightweight, no extra service; stored in `bot/data/bot.db`
- Conversation state via `_pending` dict + `register_next_step_handler` — avoids full FSM library
- Flask keep-alive on port 5000 — separate from the API server on port 8080

## User preferences

- Myanmar (Burmese) language for all bot UI
- Admin-only access enforced via environment variable
- pyTelegramBotAPI (sync polling) preferred over aiogram for simplicity on Replit

## Gotchas

- Port 8080 is already used by the Node.js API server; Flask runs on 5000
- outline-vpn-api v6.6.1 is installed (latest); API is compatible
- `bot/data/` is gitignored — SQLite DB is ephemeral on Replit free tier restarts
- Run `/cancel` mid-conversation to abort multi-step input flows
